"""Background poll — full ER:LC v2 payload."""
from __future__ import annotations

import asyncio
import logging

from config import settings
from erlc_client import ERLCClient
import state

logger = logging.getLogger("cia.poll")
client = ERLCClient()


async def broadcast_map(payload: dict) -> None:
    dead = set()
    for ws in state.map_ws:
        try:
            await ws.send_json(payload)
        except Exception:
            dead.add(ws)
    for ws in dead:
        state.map_ws.discard(ws)


def _normalize(raw: dict) -> dict:
    c = ERLCClient
    players = [c.parse_player(p) for p in (raw.get("Players") or [])]
    vehicles = [c.parse_vehicle(v) for v in (raw.get("Vehicles") or [])]
    join_logs = sorted(
        [c.parse_join_log(j) for j in (raw.get("JoinLogs") or [])],
        key=lambda x: x.get("timestamp") or 0,
        reverse=True,
    )[:100]
    kill_logs = sorted(
        [c.parse_kill_log(k) for k in (raw.get("KillLogs") or [])],
        key=lambda x: x.get("timestamp") or 0,
        reverse=True,
    )[:80]
    command_logs = sorted(
        [c.parse_command_log(k) for k in (raw.get("CommandLogs") or [])],
        key=lambda x: x.get("timestamp") or 0,
        reverse=True,
    )[:80]
    mod_calls = sorted(
        [c.parse_mod_call(k) for k in (raw.get("ModCalls") or [])],
        key=lambda x: x.get("timestamp") or 0,
        reverse=True,
    )[:40]
    emergency = [c.parse_emergency(e) for e in (raw.get("EmergencyCalls") or [])]
    queue = raw.get("Queue") or []
    if isinstance(queue, list):
        queue = [str(q).split(":")[0] if not isinstance(q, dict) else q for q in queue]
    staff = raw.get("Staff") or {}
    return {
        "players": players,
        "vehicles": vehicles,
        "join_logs": join_logs,
        "kill_logs": kill_logs,
        "command_logs": command_logs,
        "mod_calls": mod_calls,
        "emergency_calls": emergency,
        "queue": queue,
        "staff": staff,
        "server": {
            "name": raw.get("Name"),
            "owner_id": raw.get("OwnerId"),
            "co_owner_ids": raw.get("CoOwnerIds"),
            "current_players": raw.get("CurrentPlayers"),
            "max_players": raw.get("MaxPlayers"),
            "acc_verified_req": raw.get("AccVerifiedReq"),
            "team_balance": raw.get("TeamBalance"),
        },
        "last_update": raw.get("_fetched_at"),
        "player_count": len(players),
        "error": None,
        "raw_keys": list(raw.keys()),
    }


async def poll_loop() -> None:
    while True:
        try:
            raw = await client.fetch_server()  # all flags
            state.latest_data.update(_normalize(raw))
            await broadcast_map({"type": "update", "data": state.latest_data})
        except Exception as e:
            logger.error("Poll error: %s", e)
            state.latest_data["error"] = str(e)
        await asyncio.sleep(settings.poll_interval)

# بنية المشروع

```
main.py                 # تشغيل التطبيق + lifespan
config.py               # الإعدادات من Environment
database.py / models.py # قاعدة البيانات
deps.py                 # مستخدم الجلسة، صلاحيات، لوج
state.py                # بيانات لايف + WebSocket
security.py             # حماية الدخول وIP
erlc_client.py          # عميل ER:LC API
ranks.py / notify.py    # رتب + إشعارات البوت
task_seeds.py           # 120 قالب مهام
services/erlc_poll.py   # تحديث اللايف
routers/auth.py         # دخول / ديسكورد
routers/portal.py       # باقي الصفحات والـ API
templates/ + static/
```

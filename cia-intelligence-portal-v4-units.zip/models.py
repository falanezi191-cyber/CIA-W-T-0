from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text
from database import Base

def utcnow():
    return datetime.now(timezone.utc)

class Announcement(Base):
    __tablename__ = "announcements"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(120), nullable=False)
    body = Column(Text, default="")
    priority = Column(String(20), default="normal")  # normal, high, critical
    author = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    password_hash = Column(String(128), nullable=True)
    discord_id = Column(String(32), unique=True, nullable=True, index=True)
    discord_avatar = Column(String(128), default="")
    display_name = Column(String(100), nullable=False)
    rank = Column(String(50), default="Recruit")
    clearance = Column(String(20), default="Confidential")
    callsign = Column(String(30), default="")
    roblox_id = Column(String(30), default="")
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    is_locked = Column(Boolean, default=False)  # permanent lock after attack
    locked_reason = Column(Text, default="")
    locked_at = Column(DateTime, nullable=True)
    failed_attempts = Column(Integer, default=0)
    can_view_map = Column(Boolean, default=False)
    can_view_personnel = Column(Boolean, default=False)
    can_manage_personnel = Column(Boolean, default=False)
    can_view_applications = Column(Boolean, default=False)
    can_manage_applications = Column(Boolean, default=False)
    can_issue_id = Column(Boolean, default=False)
    can_view_logs = Column(Boolean, default=False)
    can_manage_blacklist = Column(Boolean, default=False)
    can_view_vehicles = Column(Boolean, default=True)
    notes = Column(Text, default="")
    duty_status = Column(String(20), default="off")  # on / off / training
    codename = Column(String(40), default="")
    roblox_username = Column(String(64), default="")
    verified_discord = Column(Boolean, default=False)
    verified_roblox = Column(Boolean, default=False)
    points = Column(Integer, default=0)
    roblox_avatar = Column(String(300), default="")
    unit = Column(String(20), default="")
    unit_number = Column(Integer, default=0)
    totp_secret = Column(String(64), default="")
    totp_enabled = Column(Boolean, default=False)
    totp_last_step = Column(Integer, default=0)
    session_version = Column(Integer, default=0)
    joined_at = Column(DateTime, default=utcnow)
    last_login = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=utcnow)

def _unit_tag(self):
    if self.unit and self.unit_number:
        return f"{self.unit}-{self.unit_number:02d}"
    return self.unit or ""
User.unit_tag = property(_unit_tag)

class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True, index=True)
    app_type = Column(String(30), default="join")
    full_name = Column(String(100), nullable=False)
    roblox_username = Column(String(64), nullable=False)
    roblox_id = Column(String(30), default="")
    discord = Column(String(80), default="")
    age = Column(String(10), default="")
    experience = Column(Text, default="")
    reason = Column(Text, default="")
    user_id = Column(Integer, default=0, index=True)
    discord_id = Column(String(32), default="")
    status = Column(String(20), default="pending")
    reviewer_note = Column(Text, default="")
    reviewed_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)
    reviewed_at = Column(DateTime, nullable=True)

class Blacklist(Base):
    __tablename__ = "blacklist"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), nullable=False)
    roblox_id = Column(String(30), default="")
    reason = Column(Text, default="")
    added_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class ActivityLog(Base):
    __tablename__ = "activity_logs"
    id = Column(Integer, primary_key=True, index=True)
    action = Column(String(100), nullable=False)
    details = Column(Text, default="")
    performed_by = Column(String(64), default="system")
    ip_address = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)
    prev_hash = Column(String(64), default="")
    entry_hash = Column(String(64), default="")

class SecurityEvent(Base):
    """Track attacks, failed logins, blocked IPs"""
    __tablename__ = "security_events"
    id = Column(Integer, primary_key=True, index=True)
    event_type = Column(String(50), nullable=False)  # failed_login, blocked_ip, locked_account, rate_limit
    ip_address = Column(String(64), default="", index=True)
    username = Column(String(64), default="")
    details = Column(Text, default="")
    severity = Column(String(20), default="medium")  # low, medium, high, critical
    created_at = Column(DateTime, default=utcnow)

class BlockedIP(Base):
    """Permanently or temporarily blocked IPs"""
    __tablename__ = "blocked_ips"
    id = Column(Integer, primary_key=True, index=True)
    ip_address = Column(String(64), unique=True, nullable=False, index=True)
    reason = Column(Text, default="")
    permanent = Column(Boolean, default=False)
    blocked_until = Column(DateTime, nullable=True)
    failed_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=utcnow)


class CaseFile(Base):
    """ملفات قضايا / تحقيقات"""
    __tablename__ = "case_files"
    id = Column(Integer, primary_key=True, index=True)
    case_code = Column(String(30), unique=True, nullable=False)
    title = Column(String(150), nullable=False)
    classification = Column(String(20), default="Confidential")
    status = Column(String(20), default="open")  # open, active, closed, archived
    summary = Column(Text, default="")
    lead_agent = Column(String(64), default="")
    created_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow)

class Operation(Base):
    """عمليات ميدانية"""
    __tablename__ = "operations"
    id = Column(Integer, primary_key=True, index=True)
    op_code = Column(String(30), default="")
    title = Column(String(150), nullable=False)
    status = Column(String(20), default="planned")  # planned, live, completed, cancelled
    location = Column(String(100), default="")
    commander = Column(String(64), default="")
    details = Column(Text, default="")
    created_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class Document(Base):
    """مكتبة الوثائق / الإجراءات"""
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(150), nullable=False)
    category = Column(String(40), default="SOP")  # SOP, Policy, Form, Intel
    classification = Column(String(20), default="Restricted")
    body = Column(Text, default="")
    author = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class Commendation(Base):
    """تكريمات / إنذارات"""
    __tablename__ = "commendations"
    id = Column(Integer, primary_key=True, index=True)
    target_username = Column(String(64), nullable=False)
    kind = Column(String(20), default="commend")  # commend, warning, strike
    reason = Column(Text, default="")
    issued_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class InternalMessage(Base):
    """بريد داخلي"""
    __tablename__ = "internal_messages"
    id = Column(Integer, primary_key=True, index=True)
    to_username = Column(String(64), nullable=False, index=True)
    from_username = Column(String(64), nullable=False)
    subject = Column(String(150), default="")
    body = Column(Text, default="")
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow)

class TrainingRecord(Base):
    """تدريب / اعتماد"""
    __tablename__ = "training_records"
    id = Column(Integer, primary_key=True, index=True)
    agent_username = Column(String(64), nullable=False)
    course = Column(String(100), nullable=False)
    status = Column(String(20), default="completed")  # scheduled, completed, failed
    score = Column(String(20), default="")
    notes = Column(Text, default="")
    instructor = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)


class Evidence(Base):
    __tablename__ = "evidence"
    id = Column(Integer, primary_key=True)
    code = Column(String(30), default="")
    title = Column(String(150), nullable=False)
    case_code = Column(String(30), default="")
    description = Column(Text, default="")
    stored_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class Watchlist(Base):
    __tablename__ = "watchlist"
    id = Column(Integer, primary_key=True)
    subject = Column(String(100), nullable=False)
    reason = Column(Text, default="")
    level = Column(String(20), default="observe")  # observe, priority, critical
    added_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class AgentNote(Base):
    __tablename__ = "agent_notes"
    id = Column(Integer, primary_key=True)
    about_username = Column(String(64), nullable=False, index=True)
    note = Column(Text, default="")
    author = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class ShiftNote(Base):
    __tablename__ = "shift_notes"
    id = Column(Integer, primary_key=True)
    shift_date = Column(String(20), default="")
    content = Column(Text, default="")
    author = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    title = Column(String(150), nullable=False)
    body = Column(Text, default="")
    level = Column(String(20), default="info")  # info, warning, code_red
    active = Column(Boolean, default=True)
    created_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class Meeting(Base):
    __tablename__ = "meetings"
    id = Column(Integer, primary_key=True)
    title = Column(String(150), nullable=False)
    when_text = Column(String(80), default="")
    location = Column(String(100), default="")
    notes = Column(Text, default="")
    created_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class InventoryItem(Base):
    __tablename__ = "inventory"
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    qty = Column(String(20), default="1")
    category = Column(String(40), default="gear")
    assigned_to = Column(String(64), default="")
    notes = Column(Text, default="")
    updated_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)


class RadioLog(Base):
    __tablename__ = "radio_logs"
    id = Column(Integer, primary_key=True)
    channel = Column(String(40), default="TAC-1")
    message = Column(Text, default="")
    author = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class Incident(Base):
    __tablename__ = "incidents"
    id = Column(Integer, primary_key=True)
    code = Column(String(30), default="")
    title = Column(String(150), nullable=False)
    postal = Column(String(20), default="")
    severity = Column(String(20), default="medium")
    status = Column(String(20), default="open")
    details = Column(Text, default="")
    reported_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class LeaveRequest(Base):
    __tablename__ = "leave_requests"
    id = Column(Integer, primary_key=True)
    username = Column(String(64), nullable=False)
    leave_type = Column(String(30), default="leave")
    from_date = Column(String(20), default="")
    to_date = Column(String(20), default="")
    reason = Column(Text, default="")
    status = Column(String(20), default="pending")
    reviewed_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class PayrollNote(Base):
    __tablename__ = "payroll_notes"
    id = Column(Integer, primary_key=True)
    username = Column(String(64), nullable=False)
    amount = Column(String(30), default="")
    period = Column(String(40), default="")
    note = Column(Text, default="")
    issued_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class CourtCase(Base):
    __tablename__ = "court_cases"
    id = Column(Integer, primary_key=True)
    code = Column(String(30), default="")
    title = Column(String(150), nullable=False)
    defendant = Column(String(100), default="")
    status = Column(String(20), default="pending")
    verdict = Column(Text, default="")
    notes = Column(Text, default="")
    created_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class Briefing(Base):
    __tablename__ = "briefings"
    id = Column(Integer, primary_key=True)
    title = Column(String(150), nullable=False)
    body = Column(Text, default="")
    shift = Column(String(40), default="")
    author = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)


class DivisionTask(Base):
    """مهام يومية / أسبوعية للفرق DI HR FOD SOG"""
    __tablename__ = "division_tasks"
    id = Column(Integer, primary_key=True)
    division = Column(String(20), nullable=False, index=True)  # DI, HR, FOD, SOG
    title = Column(String(150), nullable=False)
    description = Column(Text, default="")
    task_date = Column(String(20), default="")  # YYYY-MM-DD
    status = Column(String(20), default="pending")  # pending, in_progress, done, cancelled
    priority = Column(String(20), default="normal")  # low, normal, high, critical
    created_by = Column(String(64), default="")
    updated_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow)

class PersonalTask(Base):
    """مهام فردية لأي عضو (خارج مهام الفرقة)"""
    __tablename__ = "personal_tasks"
    id = Column(Integer, primary_key=True)
    assigned_to = Column(String(64), nullable=False, index=True)
    title = Column(String(150), nullable=False)
    description = Column(Text, default="")
    task_date = Column(String(20), default="")
    status = Column(String(20), default="pending")
    priority = Column(String(20), default="normal")
    created_by = Column(String(64), default="")
    updated_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow)


class SiteNotification(Base):
    __tablename__ = "site_notifications"
    id = Column(Integer, primary_key=True)
    to_username = Column(String(64), nullable=False, index=True)
    title = Column(String(150), default="")
    body = Column(Text, default="")
    link = Column(String(200), default="")
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow)


class RadioChannelLock(Base):
    """قنوات مقيدة — الأونر يحدد من يدخل أي موجة"""
    __tablename__ = "radio_channel_locks"
    id = Column(Integer, primary_key=True)
    channel = Column(Integer, nullable=False, unique=True)  # 1-120
    label = Column(String(60), default="")
    locked = Column(Boolean, default=True)
    allowed_ranks = Column(String(200), default="")  # comma ranks or empty=owners only
    created_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class RadioMessage(Base):
    __tablename__ = "radio_messages"
    id = Column(Integer, primary_key=True)
    channel = Column(Integer, nullable=False, index=True)
    author = Column(String(64), default="")
    callsign = Column(String(40), default="")
    body = Column(Text, default="")
    created_at = Column(DateTime, default=utcnow)

class TaskTemplate(Base):
    __tablename__ = "task_templates"
    id = Column(Integer, primary_key=True)
    division = Column(String(20), default="")
    title = Column(String(150), nullable=False)
    description = Column(Text, default="")
    created_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)


class TaskCompletion(Base):
    """إثبات إنجاز مهمة — صور أو شهود"""
    __tablename__ = "task_completions"
    id = Column(Integer, primary_key=True)
    task_type = Column(String(20), default="division")  # division | personal
    task_id = Column(Integer, default=0)
    submitter = Column(String(64), default="")
    evidence_text = Column(Text, default="")
    witnesses = Column(Text, default="")  # usernames comma
    file_path = Column(String(250), default="")
    status = Column(String(20), default="pending")  # pending, approved, rejected
    points_awarded = Column(Integer, default=0)
    reviewed_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

"""RFC 6238 TOTP using only the standard library (works with Google/Microsoft Authenticator, Authy...)."""
import base64, hashlib, hmac, secrets, struct, time
from urllib.parse import quote

def new_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")

def _code(secret: str, step: int) -> str:
    key = base64.b32decode(secret + "=" * (-len(secret) % 8), casefold=True)
    h = hmac.new(key, struct.pack(">Q", step), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    return str((struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % 1_000_000).zfill(6)

def verify(secret: str, code: str, last_step: int = 0, window: int = 1):
    """Return the matched time-step (int) or None. Rejects reuse of an already-used step."""
    code = (code or "").strip().replace(" ", "")
    if not secret or len(code) != 6 or not code.isdigit():
        return None
    now = int(time.time() // 30)
    for s in range(now - window, now + window + 1):
        if s > (last_step or 0) and hmac.compare_digest(_code(secret, s), code):
            return s
    return None

def uri(secret: str, account: str, issuer: str = "CIA Portal") -> str:
    return f"otpauth://totp/{quote(issuer)}:{quote(account)}?secret={secret}&issuer={quote(issuer)}&digits=6&period=30"

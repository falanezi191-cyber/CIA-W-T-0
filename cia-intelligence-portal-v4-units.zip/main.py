"""
CIA Intelligence Portal — ER:LC
Entry point: app factory, lifespan, router includes.
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from fastapi.responses import JSONResponse, PlainTextResponse, RedirectResponse
from starlette.middleware.sessions import SessionMiddleware

from config import settings
from limiter import limiter
from database import SessionLocal, init_db
from deps import hash_password
from models import User
from services.erlc_poll import client, poll_loop
from routers import auth as auth_router
from routers import portal as portal_router
from routers import shield as shield_router
from routers import linking as linking_router
from routers import units as units_router

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("cia")

poll_task = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global poll_task
    from pathlib import Path

    if not settings.debug:
        if not settings.secret_key or settings.secret_key.startswith("dev-only") or len(settings.secret_key) < 32:
            raise RuntimeError("SECRET_KEY must be set to a random string of 32+ characters")
        if settings.admin_password in ("", "ChangeMeNow!"):
            raise RuntimeError("ADMIN_PASSWORD must be set (default password is not allowed)")
    Path("data").mkdir(exist_ok=True)
    Path("data/uploads").mkdir(parents=True, exist_ok=True)
    init_db()

    # Seed task templates (120)
    try:
        from task_seeds import all_template_rows
        from models import TaskTemplate

        db = SessionLocal()
        if db.query(TaskTemplate).count() < 100:
            for row in all_template_rows():
                exists = (
                    db.query(TaskTemplate)
                    .filter(
                        TaskTemplate.division == row["division"],
                        TaskTemplate.title == row["title"],
                    )
                    .first()
                )
                if not exists:
                    db.add(
                        TaskTemplate(
                            division=row["division"],
                            title=row["title"],
                            description=row["description"],
                            created_by="system",
                        )
                    )
            db.commit()
            logger.info("Seeded division task templates")
        db.close()
    except Exception as e:
        logger.warning("template seed: %s", e)

    # Default admin
    db = SessionLocal()
    try:
        admin = db.query(User).filter(User.username == settings.admin_username).first()
        if not admin and settings.admin_password:
            admin = User(
                username=settings.admin_username,
                password_hash=hash_password(settings.admin_password),
                display_name="Director",
                rank="Owner",
                clearance="Top Secret",
                is_admin=True,
                can_view_map=True,
                can_view_personnel=True,
                can_manage_personnel=True,
                can_view_applications=True,
                can_manage_applications=True,
                can_issue_id=True,
                can_view_logs=True,
                can_manage_blacklist=True,
                can_view_vehicles=True,
            )
            db.add(admin)
            db.commit()
            logger.info("Default admin created: %s", settings.admin_username)
    finally:
        db.close()

    await client.start()
    poll_task = asyncio.create_task(poll_loop())
    if not settings.secret_key or str(settings.secret_key).startswith("dev-only"):
        logger.warning("Set a strong SECRET_KEY in Environment")
    if not settings.erlc_server_key:
        logger.warning("ERLC_SERVER_KEY empty — live data disabled until set")
    logger.info("CIA Portal started")
    yield
    if poll_task:
        poll_task.cancel()
    await client.close()


app = FastAPI(title="CIA Intelligence Portal", lifespan=lifespan, docs_url=None, redoc_url=None)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


CSP = (
    "default-src 'self'; "
    "script-src 'self' 'unsafe-inline' https://unpkg.com; "
    "style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com; "
    "font-src 'self' https://fonts.gstatic.com data:; "
    "img-src 'self' data: https://*.rbxcdn.com https://api.erlc.gg https://*.tile.openstreetmap.org https://cdn.discordapp.com; "
    "connect-src 'self' wss: ws:; "
    "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
)

SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    # CSRF defence: state-changing requests must come from our own origin.
    if request.method not in SAFE_METHODS:
        origin = request.headers.get("origin") or request.headers.get("referer")
        if origin:
            from urllib.parse import urlparse

            host = request.headers.get("x-forwarded-host") or request.headers.get("host") or ""
            if urlparse(origin).netloc != host:
                return PlainTextResponse("Cross-site request blocked", status_code=403)
    try:
        if int(request.headers.get("content-length", 0)) > settings.max_body_bytes:
            return PlainTextResponse("Request too large", status_code=413)
    except ValueError:
        return PlainTextResponse("Bad request", status_code=400)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = CSP
    if not settings.debug:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    if request.method == "GET" and request.url.path not in ("/healthz",) and not request.url.path.startswith("/static"):
        response.headers["Cache-Control"] = "no-store"  # never cache authenticated pages
    return response


OPEN_PREFIXES = ("/login", "/logout", "/auth/", "/static", "/healthz", "/link/", "/account/",
                 "/api/notif-count", "/notifications", "/my-application", "/apply", "/verify/")


@app.middleware("http")
async def access_gate(request: Request, call_next):
    """Everyone must have Discord + a verified Roblox link; new members only see the application page."""
    path = request.url.path
    uid = request.session.get("user_id") if "session" in request.scope else None
    if uid and not path.startswith(OPEN_PREFIXES):
        from models import User
        from ranks import is_owner_identity
        db = SessionLocal()
        try:
            u = db.query(User).filter(User.id == uid, User.is_active == True).first()
            if u and not (u.is_admin or is_owner_identity(u.username)):
                if not (u.verified_roblox and u.roblox_id):
                    return RedirectResponse("/link/roblox", status_code=303)
                if (u.rank or "Recruit") == "Recruit":
                    return RedirectResponse("/my-application", status_code=303)
        finally:
            db.close()
    return await call_next(request)


@app.get("/healthz", include_in_schema=False)
async def healthz():
    return {"ok": True}


app.add_middleware(
    SessionMiddleware,
    secret_key=settings.secret_key or "dev-only-change-me-in-production-32chars",
    max_age=settings.session_max_age,
    same_site="lax",
    https_only=not settings.debug,
)
app.mount("/static", StaticFiles(directory="static"), name="static")

app.include_router(auth_router.router)
app.include_router(portal_router.router)
app.include_router(shield_router.router)
app.include_router(linking_router.router)
app.include_router(units_router.router)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=settings.port, reload=settings.debug)

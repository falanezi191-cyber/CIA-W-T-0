"""Send lightweight events to the standalone Discord bot. Site stays independent."""
from __future__ import annotations
import logging
from typing import Any, Dict, Optional
import httpx
from config import settings

log = logging.getLogger("notify")

async def notify_bot(payload: Dict[str, Any]) -> bool:
    url = getattr(settings, "bot_notify_url", "") or ""
    secret = getattr(settings, "bot_notify_secret", "") or ""
    if not url:
        return False
    headers = {"Content-Type": "application/json"}
    if secret:
        headers["X-CIA-Secret"] = secret
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            r = await client.post(url, json=payload, headers=headers)
            if r.status_code >= 400:
                log.warning("notify failed %s: %s", r.status_code, r.text[:200])
                return False
            return True
    except Exception as e:
        log.warning("notify error: %s", e)
        return False

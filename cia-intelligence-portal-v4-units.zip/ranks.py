"""Rank hierarchy — f_ksa9 is supreme owner."""
RANK_LEVEL = {
    "Owner": 100,
    "أونر": 100,
    "Director": 90,
    "Deputy Director": 80,
    "SAC": 60,
    "HR": 55,
    "Special Agent": 50,
    "Agent": 40,
    "Recruit": 10,
}

# All portal owners
PORTAL_OWNERS = {
    "f_ksa9",
    "fysl3",
}

# Supreme — always wins, can manage everyone including other owners if needed
SUPREME_OWNERS = {
    "f_ksa9",
}

def level(rank: str) -> int:
    if not rank:
        return 0
    r = rank.strip()
    if r in RANK_LEVEL:
        return RANK_LEVEL[r]
    low = r.lower()
    for k, v in RANK_LEVEL.items():
        if k.lower() in low or low in k.lower():
            return v
    return 20

def is_owner_identity(username: str = "", discord_name: str = "", display_name: str = "") -> bool:
    names = {(username or "").lower(), (discord_name or "").lower(), (display_name or "").lower()}
    owners = {o.lower() for o in PORTAL_OWNERS}
    return bool(names & owners)

def is_supreme(username: str = "", display_name: str = "") -> bool:
    names = {(username or "").lower(), (display_name or "").lower()}
    return bool(names & {s.lower() for s in SUPREME_OWNERS})

def can_manage_user(actor_rank: str, actor_is_admin: bool, target_rank: str, target_is_admin: bool,
                    actor_username: str = "", target_username: str = "") -> bool:
    # Supreme owner controls everyone
    if is_supreme(actor_username):
        return True
    # Nobody locks/edits supreme except themselves (no)
    if is_supreme(target_username):
        return False
    # Other owners cannot fight each other
    if is_owner_identity(actor_username) and is_owner_identity(target_username):
        return False
    if is_owner_identity(target_username) and not is_owner_identity(actor_username):
        return False
    al = level(actor_rank)
    tl = level(target_rank)
    if al >= 100 and tl >= 100:
        return False
    if tl >= 100 and al < 100:
        return False
    if is_owner_identity(actor_username):
        return True
    if al > tl:
        return True
    if actor_is_admin and tl < 90:
        return True
    return False


# Optional: rank name contains division for lead powers
DIVISION_LEAD_MARKERS = {
    "DI": ["DI", "di lead", "di-"],
    "HR": ["HR"],
    "FOD": ["FOD", "fod"],
    "SOG": ["SOG", "sog"],
}

def can_manage_division(user_rank: str, username: str, division: str, is_admin: bool = False) -> bool:
    if is_supreme(username) or is_owner_identity(username) or is_admin:
        return True
    r = (user_rank or "").upper()
    div = (division or "").upper()
    markers = DIVISION_LEAD_MARKERS.get(div, [div])
    return any(m.upper() in r for m in markers)

from pydantic_settings import BaseSettings
from typing import Dict, Any

class Settings(BaseSettings):
    erlc_server_key: str = ""
    secret_key: str = "dev-only-change-me-in-production-32chars"
    session_max_age: int = 60 * 60 * 12
    idle_timeout: int = 60 * 60 * 2   # auto-logout after 2h of inactivity
    max_body_bytes: int = 6_000_000

    # Discord OAuth – put real values in Render Environment Variables only
    discord_client_id: str = ""
    discord_client_secret: str = ""
    discord_guild_id: str = ""
    discord_redirect_uri: str = ""  # https://YOUR-APP.onrender.com/auth/discord/callback
    discord_bot_token: str = ""     # optional but recommended

    poll_interval: float = 4.0
    port: int = 8000
    debug: bool = False
    admin_username: str = "f_ksa9"
    admin_password: str = "ChangeMeNow!"
    map_size: int = 5355
    map_scale: float = 1.0
    database_url: str = "sqlite:///./data/cia.db"

    # Server automation (bot gives the role + nickname on acceptance)
    discord_accepted_role_id: str = ""     # CIA member role given when an application is accepted
    discord_applicant_role_id: str = "1525986271447613642"  # new-members role (removed on acceptance)

    # Units (فرق): names are configurable, e.g. UNITS=DI,HR,FOD,SOG
    units: str = "DI,HR,FOD,SOG"

    # Security
    owner_discord_ids: str = ""     # comma-separated Discord user IDs that may become Owner via Discord login
    trusted_proxy_hops: int = 1     # Render = 1 reverse proxy; used to read the real client IP safely

    # Optional AI (OpenAI-compatible: OpenAI, xAI Grok, etc.)
    ai_api_key: str = ""
    ai_base_url: str = "https://api.openai.com/v1"
    ai_model: str = "gpt-4o-mini"

    # Standalone Discord bot notify bridge (optional)
    bot_notify_url: str = ""   # e.g. http://your-vps:8090/notify
    bot_notify_secret: str = ""

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()
UNITS = [x.strip().upper() for x in settings.units.split(",") if x.strip()]
OWNER_DISCORD_IDS = {x.strip() for x in settings.owner_discord_ids.split(",") if x.strip()}

# Discord Role ID → rank + permissions
# Role 1525986271447613642 = New members → Recruit (view applications only)
ROLE_MAP: Dict[str, Dict[str, Any]] = {
    # HR role
    "1549014237870034944": {
        "rank": "HR",
        "clearance": "Secret",
        "is_admin": False,
        "can_view_map": False,
        "can_view_personnel": True,
        "can_manage_personnel": True,
        "can_view_applications": True,
        "can_manage_applications": True,
        "can_issue_id": True,
        "can_view_logs": True,
        "can_manage_blacklist": False,
        "can_view_vehicles": False,
    },
    "1525986271447613642": {
        "rank": "Recruit",
        "clearance": "Restricted",
        "is_admin": False,
        "can_view_map": False,
        "can_view_personnel": False,
        "can_manage_personnel": False,
        "can_view_applications": True,
        "can_manage_applications": False,
        "can_issue_id": False,
        "can_view_logs": False,
        "can_manage_blacklist": False,
        "can_view_vehicles": False,
    },
}

# Highest priority first when multiple roles match
ROLE_PRIORITY = [
    "1549014237870034944",  # HR
    "1525986271447613642",  # Recruit — applications only
    # Add higher Discord role IDs above Recruit in this list (first match wins if you reorder)
]

# Manual ranks used in admin UI: Minister, Director, Deputy Director, SAC, Special Agent, Agent, Recruit

# Accepted-member role → Agent permissions (only if DISCORD_ACCEPTED_ROLE_ID is set)
if settings.discord_accepted_role_id:
    ROLE_MAP[settings.discord_accepted_role_id] = {
        "rank": "Agent", "clearance": "Confidential", "is_admin": False,
        "can_view_map": True, "can_view_personnel": False, "can_manage_personnel": False,
        "can_view_applications": False, "can_manage_applications": False, "can_issue_id": False,
        "can_view_logs": False, "can_manage_blacklist": False, "can_view_vehicles": True,
    }
    ROLE_PRIORITY.insert(1, settings.discord_accepted_role_id)   # right after HR

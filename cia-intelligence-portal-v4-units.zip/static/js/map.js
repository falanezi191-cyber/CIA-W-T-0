(function () {
  "use strict";
  const MAP_SIZE = window.MAP_SIZE || 5355;
  const MAP_SCALE = window.MAP_SCALE || 1.0;
  let players = [], markers = new Map(), ws = null;

  function gameToPixel(x, z) {
    const half = MAP_SIZE / 2;
    return [half + (z / MAP_SCALE), half + (x / MAP_SCALE)];
  }

  function teamColor(team) {
    if (!team) return "#94a3b8";
    const t = team.toLowerCase();
    if (t.includes("police") || t.includes("sheriff")) return "#3b82f6";
    if (t.includes("fire") || t.includes("ems")) return "#ef4444";
    if (t.includes("dot")) return "#f59e0b";
    if (t.includes("criminal")) return "#a855f7";
    if (t.includes("civilian")) return "#22c55e";
    return "#94a3b8";
  }

  const map = L.map("map", {
    crs: L.CRS.Simple,
    minZoom: -2,
    maxZoom: 3,
  });
  const bounds = [[0, 0], [MAP_SIZE, MAP_SIZE]];
  L.imageOverlay("https://api.erlc.gg/maps/fall_postals.png", bounds).addTo(map);
  map.fitBounds(bounds);
  map.setMaxBounds(bounds.pad(0.1));

  function updateMarkers(list) {
    const seen = new Set();
    list.forEach(p => {
      if (!p.has_location || p.location.x == null) return;
      const id = p.id || p.raw;
      seen.add(id);
      const pos = gameToPixel(p.location.x, p.location.z);
      const color = teamColor(p.team);
      const html = `<div style="width:12px;height:12px;border-radius:50%;background:${color};border:2px solid #fff;box-shadow:0 0 6px rgba(0,0,0,.5)"></div>`;
      const icon = L.divIcon({ className: "", html, iconSize: [12,12], iconAnchor: [6,6] });
      if (markers.has(id)) {
        markers.get(id).setLatLng(pos).setIcon(icon);
      } else {
        const m = L.marker(pos, { icon, title: p.username }).addTo(map);
        m.bindPopup(`<b>${p.username}</b><br>${p.team || ""}<br>${p.location.postal || ""}`);
        markers.set(id, m);
      }
    });
    for (const [id, m] of markers) {
      if (!seen.has(id)) { map.removeLayer(m); markers.delete(id); }
    }
  }

  function connect() {
    const proto = location.protocol === "https:" ? "wss" : "ws";
    ws = new WebSocket(`${proto}://${location.host}/ws`);
    ws.onopen = () => {
      document.getElementById("conn-status").textContent = "متصل";
      document.getElementById("conn-status").className = "badge badge-green";
    };
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === "update" && msg.data) {
          players = msg.data.players || [];
          updateMarkers(players);
          document.getElementById("player-count").textContent = (msg.data.player_count || 0) + " لاعب";
        }
      } catch(e) {}
    };
    ws.onclose = () => {
      document.getElementById("conn-status").textContent = "غير متصل";
      document.getElementById("conn-status").className = "badge badge-red";
      setTimeout(connect, 3000);
    };
  }

  document.getElementById("player-search").addEventListener("input", function() {
    const q = this.value.toLowerCase();
    if (!q) return;
    const p = players.find(x => (x.username||"").toLowerCase().includes(q));
    if (p && p.has_location) {
      map.setView(gameToPixel(p.location.x, p.location.z), 2);
    }
  });

  const params = new URLSearchParams(location.search);
  const focusPostal = params.get("postal");
  // after markers update, try focus postal once
  let focused = false;
  const _um = updateMarkers;
  updateMarkers = function(list) {
    _um(list);
    if (focusPostal && !focused) {
      const p = list.find(x => x.location && String(x.location.postal||"") === String(focusPostal));
      if (p && p.has_location) {
        map.setView(gameToPixel(p.location.x, p.location.z), 2);
        focused = true;
      }
    }
  };
  connect();
})();

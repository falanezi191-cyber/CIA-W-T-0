"""Act on the CIA Discord server through the bot token (roles + nickname)."""
from __future__ import annotations

import logging
from urllib.parse import quote

import httpx

from config import settings

log = logging.getLogger("cia.discord")
API = "https://discord.com/api/v10"


def enabled() -> bool:
    return bool(settings.discord_bot_token and settings.discord_guild_id)


async def sync_member(discord_id: str, add_roles=(), remove_roles=(), nick: str = "", reason: str = "CIA Portal") -> dict:
    """Give/remove roles and set the nickname. Never raises; returns {'ok': bool, 'errors': [...]}."""
    out = {"ok": True, "errors": []}
    if not enabled() or not discord_id:
        return {"ok": False, "errors": ["bot not configured"]}
    base = f"{API}/guilds/{settings.discord_guild_id}/members/{discord_id}"
    headers = {"Authorization": f"Bot {settings.discord_bot_token}", "X-Audit-Log-Reason": quote(reason)}
    try:
        async with httpx.AsyncClient(timeout=10.0, headers=headers) as c:
            for rid in add_roles:
                if rid:
                    r = await c.put(f"{base}/roles/{rid}")
                    if r.status_code not in (200, 204):
                        out["errors"].append(f"add {rid}: {r.status_code}")
            for rid in remove_roles:
                if rid:
                    r = await c.delete(f"{base}/roles/{rid}")
                    if r.status_code not in (200, 204):
                        out["errors"].append(f"remove {rid}: {r.status_code}")
            if nick:
                r = await c.patch(base, json={"nick": nick[:32]})
                if r.status_code != 200:
                    out["errors"].append(f"nick: {r.status_code}")
    except Exception as e:
        out["errors"].append(str(e))
    out["ok"] = not out["errors"]
    if out["errors"]:
        log.warning("discord sync %s: %s", discord_id, out["errors"])
    return out

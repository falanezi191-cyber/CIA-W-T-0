"""Shared dependencies and request helpers."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from fastapi import Request
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from models import User, ActivityLog, SiteNotification
from ranks import is_owner_identity, is_supreme

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    if not hashed:
        return False
    return pwd_context.verify(plain, hashed)


def get_current_user(request: Request, db: Session) -> Optional[User]:
    import time
    from config import settings

    uid = request.session.get("user_id")
    if not uid:
        return None
    now = int(time.time())
    last = request.session.get("ts", now)
    if now - last > settings.idle_timeout:      # idle timeout
        request.session.clear()
        return None
    user = db.query(User).filter(User.id == uid, User.is_active == True).first()
    if not user or request.session.get("sv", 0) != (user.session_version or 0):
        request.session.clear()                  # "logout everywhere" / password change
        return None
    request.session["ts"] = now
    return user


def start_session(request: Request, user: User) -> None:
    import time
    request.session.clear()
    request.session["user_id"] = user.id
    request.session["sv"] = user.session_version or 0
    request.session["ts"] = int(time.time())


def _chain_hash(prev: str, action: str, details: str, by: str, ts: str) -> str:
    import hashlib, hmac
    from config import settings
    msg = "\x1f".join((prev, action, details, by, ts)).encode()
    return hmac.new(settings.secret_key.encode(), msg, hashlib.sha256).hexdigest()


def log_action(db: Session, action: str, details: str = "", by: str = "system") -> None:
    """Append-only, HMAC-chained audit log: editing or deleting any row breaks the chain."""
    last = db.query(ActivityLog).order_by(ActivityLog.id.desc()).first()
    prev = (last.entry_hash if last and last.entry_hash else "")
    ts = datetime.now(timezone.utc).replace(microsecond=0)
    row = ActivityLog(action=action[:100], details=details, performed_by=by, created_at=ts,
                      prev_hash=prev,
                      entry_hash=_chain_hash(prev, action[:100], details, by, ts.isoformat()))
    db.add(row)
    db.commit()


def verify_audit_chain(db: Session) -> dict:
    prev, checked, broken = "", 0, None
    for r in db.query(ActivityLog).order_by(ActivityLog.id.asc()).yield_per(500):
        if not r.entry_hash:        # legacy rows from before the shield
            continue
        ts = r.created_at.replace(tzinfo=timezone.utc).replace(microsecond=0).isoformat()
        if r.prev_hash != prev or r.entry_hash != _chain_hash(prev, r.action, r.details or "", r.performed_by or "", ts):
            broken = r.id
            break
        prev, checked = r.entry_hash, checked + 1
    return {"ok": broken is None, "checked": checked, "broken_at": broken}


async def push_site_notif(
    db: Session, to_username: str, title: str, body: str = "", link: str = ""
) -> None:
    if not to_username:
        return
    db.add(
        SiteNotification(
            to_username=to_username[:64],
            title=title[:150],
            body=body[:500],
            link=link[:200],
        )
    )
    db.commit()


def elevate_if_owner(user: User, via_discord: bool = False) -> None:
    """Grant full Owner powers to portal owners.

    Only the immutable identity counts: the portal username (set by us, not by the
    user) or a whitelisted Discord ID. Display names are user-controlled on Discord
    and must never grant privileges.
    """
    from config import OWNER_DISCORD_IDS

    if via_discord:
        if not (user.discord_id and user.discord_id in OWNER_DISCORD_IDS):
            return
    else:
        if not is_owner_identity(user.username):
            return
    user.rank = "Owner"
    user.clearance = "Top Secret"
    user.is_admin = True
    user.is_active = True
    user.is_locked = False
    user.failed_attempts = 0
    user.locked_reason = ""
    for flag in (
        "can_view_map",
        "can_view_personnel",
        "can_manage_personnel",
        "can_view_applications",
        "can_manage_applications",
        "can_issue_id",
        "can_view_logs",
        "can_manage_blacklist",
        "can_view_vehicles",
    ):
        setattr(user, flag, True)


def is_fully_verified(user: Optional[User]) -> bool:
    return bool(user and user.verified_roblox and user.roblox_id and (user.verified_discord or user.password_hash))


def can_manage_tasks(user: Optional[User]) -> bool:
    return bool(
        user
        and (user.is_admin or is_owner_identity(user.username) or is_supreme(user.username))
    )

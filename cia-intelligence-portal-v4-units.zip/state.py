"""Runtime shared state (live ER:LC data + websocket clients)."""
from __future__ import annotations

from typing import Any, Dict, Set

from fastapi import WebSocket

latest_data: Dict[str, Any] = {
    "players": [],
    "vehicles": [],
    "join_logs": [],
    "kill_logs": [],
    "command_logs": [],
    "mod_calls": [],
    "emergency_calls": [],
    "queue": [],
    "staff": {},
    "server": {},
    "last_update": None,
    "player_count": 0,
    "error": None,
    "raw_keys": [],
}

map_ws: Set[WebSocket] = set()
radio_ws: Set[WebSocket] = set()

# CIA Intelligence Portal — ER:LC

موقع متكامل لقطاع CIA مع تسجيل دخول Discord + صلاحيات حسب الرول + حماية أمنية قوية.

## المميزات الأمنية
- Rate limiting على صفحات الدخول والتقديم (مفتاحه IP حقيقي غير قابل للتزوير)
- Security Headers (CSP, HSTS, X-Frame-Options, Permissions-Policy) + حماية CSRF بفحص Origin
- Sessions آمنة (SameSite + HTTPS only)
- إخفاء /docs و /redoc
- تحقق من OAuth state ضد CSRF
- عدم تخزين الـ Client Secret في الكود

## Discord Role Mapping
رولات الديسكورد مضبوطة في `config.py` → `ROLE_MAP` (Recruit / HR).
عدّل `ROLE_MAP` في `config.py` لإضافة رولات أخرى.

## إعداد Render

### Environment Variables (ضعها كلها):
```
ERLC_SERVER_KEY=...
SECRET_KEY=...long random...
DISCORD_CLIENT_ID=
DISCORD_CLIENT_SECRET=
DISCORD_GUILD_ID=
DISCORD_REDIRECT_URI=https://YOUR-APP.onrender.com/auth/discord/callback
ADMIN_USERNAME=admin
ADMIN_PASSWORD=...
```

### Discord Developer Portal
1. OAuth2 → Redirects → أضف نفس رابط DISCORD_REDIRECT_URI
2. OAuth2 → Scopes: identify, guilds, guilds.members.read
3. (مستحسن) أنشئ بوت وفعّل Server Members Intent، ثم ضع DISCORD_BOT_TOKEN

### Build / Start
- Build: `pip install -r requirements.txt`
- Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`

## ملاحظات
- بعد أول دخول بـ Discord يتم إنشاء الحساب تلقائياً وربط الرول.
- الأدمن الافتراضي يبقى متاحاً باليوزر/باسورد.

## 🛡️ درع الحماية (v2)
- توثيق ثنائي TOTP (/account/security) — متوافق مع Google Authenticator/Authy، رمز لمرة واحدة
- سجل تدقيق مربوط بتشفير HMAC متسلسل (أي تعديل/حذف يُكتشف) — /admin/audit/verify
- انتهاء الجلسة بعد ساعتين خمول + "خروج من كل الأجهزة" + إبطال الجلسات عند تغيير الباسورد
- سياسة باسورد: 12+ خانة وحروف وأرقام
- تنبيهات فورية للديسكورد عند الهجمات (حظر IP، قفل حساب)
- حد حجم الطلبات، CSP، فحص Origin ضد CSRF، WebSocket بمصادقة
- نسخة احتياطية كاملة للقاعدة للأونر الأعلى فقط (/admin/backup/db)

## 🔗 ربط Discord + Roblox + التقديم التلقائي (v3)
1. العضو يدخل بـ Discord ← الموقع يقرأ رولاته من السيرفر.
2. إذا ما عنده Roblox مربوط ← /link/roblox: يكتب اسمه، ياخذ كود، يحطه في وصف حسابه، والموقع يتحقق من Roblox مباشرة (إثبات ملكية حقيقي).
3. الرتبة الجديدة (Recruit) ما يشوف إلا صفحة التقديم /my-application.
4. عند القبول: الموقع يعطي رول الأعضاء، يسحب رول المتقدمين، ويغيّر النك نيم إلى [الرتبة] اسم_روبلوكس عبر البوت.
5. صورة Roblox تظهر في بطاقة الهوية وصفحتي وتتحدّث مع كل دخول.

## 🧩 نظام الفرق (Units) — v4
- كل عضو له فرقة + رقم داخلها (مثال FOD-07). الفرق من متغير `UNITS` (الافتراضي DI,HR,FOD,SOG).
- صفحة /units: قائمة كل فرقة مرتبة بالأرقام + تعيين/نقل/إزالة لمن عنده صلاحية (أدمن، إدارة الأفراد، أو قائد الفرقة).
- الرقم فاضي = أول رقم متاح تلقائياً، ولا يتكرر داخل نفس الفرقة.
- يتحدّث تلقائياً: النك نيم في الديسكورد `[الرتبة] FOD-07 | الاسم`، الكولساين (للراديو)، بطاقة الهوية، وصفحتي.

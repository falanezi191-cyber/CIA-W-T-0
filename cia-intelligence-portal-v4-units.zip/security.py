"""
CIA Portal — Smart Security
- Bad internet friendly (high attempt tolerance if slow)
- Hard against rapid brute-force
"""
from __future__ import annotations
from datetime import datetime, timezone, timedelta
from typing import Optional, Tuple
from sqlalchemy.orm import Session
from models import User, SecurityEvent, BlockedIP

# Soft thresholds (bad connection OK)
MAX_FAILED_ACCOUNT_SLOW = 30      # lock account only after 30 fails in window
MAX_FAILED_IP_SLOW = 40           # temp ban IP after 40 slow fails

# Hard thresholds (rapid attack)
RAPID_WINDOW_SECONDS = 120        # 2 minutes
RAPID_MAX_ATTEMPTS = 12           # 12 tries in 2 min = attack
IP_TEMP_BAN_MINUTES = 45
IP_PERM_AFTER_TEMP_BANS = 4       # permanent after repeated temp bans
WINDOW_MINUTES = 60               # count window for slow fails

def utcnow():
    return datetime.now(timezone.utc)

def get_client_ip(request) -> str:
    """Real client IP. X-Forwarded-For is client-controlled on the left side, so we
    count from the right: with N trusted proxies the real IP is the Nth entry from the end."""
    from config import settings
    xff = request.headers.get("x-forwarded-for")
    if xff:
        parts = [p.strip() for p in xff.split(",") if p.strip()]
        hops = max(1, settings.trusted_proxy_hops)
        if parts:
            return parts[-hops if len(parts) >= hops else 0][:64]
    if request.client:
        return (request.client.host or "unknown")[:64]
    return "unknown"

def _aware(dt):
    """SQLite returns naive datetimes; make them comparable with utcnow()."""
    if dt is not None and dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt

def is_ip_blocked(db: Session, ip: str) -> Tuple[bool, str]:
    row = db.query(BlockedIP).filter(BlockedIP.ip_address == ip).first()
    if not row:
        return False, ""
    if row.permanent:
        return True, "عنوان جهازك محظور بشكل دائم بسبب هجمات متكررة. تواصل مع إدارة القطاع إن كان خطأ."
    until = _aware(row.blocked_until)
    if until and until > utcnow():
        mins = int((until - utcnow()).total_seconds() / 60) + 1
        return True, f"عنوان جهازك محظور مؤقتًا. حاول بعد حوالي {mins} دقيقة."
    if until and until <= utcnow():
        row.blocked_until = None
        db.commit()
    return False, ""

def record_security_event(db: Session, event_type: str, ip: str, username: str = "", details: str = "", severity: str = "medium"):
    db.add(SecurityEvent(
        event_type=event_type, ip_address=ip, username=(username or "")[:64],
        details=(details or "")[:500], severity=severity,
    ))
    db.commit()
    if severity in ("high", "critical"):
        try:
            import asyncio
            from notify import notify_bot
            asyncio.get_running_loop().create_task(notify_bot({
                "type": "custom",
                "message": f"🛡️ [{severity.upper()}] {event_type} · IP {ip} · {username or '-'} · {(details or '')[:120]}",
            }))
        except Exception:
            pass

def _count_fails(db: Session, ip: str, seconds: int = None, minutes: int = None) -> int:
    if seconds:
        since = utcnow() - timedelta(seconds=seconds)
    else:
        since = utcnow() - timedelta(minutes=minutes or WINDOW_MINUTES)
    return db.query(SecurityEvent).filter(
        SecurityEvent.ip_address == ip,
        SecurityEvent.event_type == "failed_login",
        SecurityEvent.created_at >= since,
    ).count()

def handle_failed_login(db: Session, ip: str, username: str) -> dict:
    result = {
        "account_locked": False,
        "ip_banned": False,
        "message": "بيانات الدخول غير صحيحة. إذا كان نتّك بطيء يمكنك المحاولة مرة أخرى بهدوء.",
    }
    record_security_event(db, "failed_login", ip, username, "Invalid credentials", "medium")

    # --- Rapid-fire detection (real attack) ---
    rapid = _count_fails(db, ip, seconds=RAPID_WINDOW_SECONDS)
    if rapid >= RAPID_MAX_ATTEMPTS:
        row = db.query(BlockedIP).filter(BlockedIP.ip_address == ip).first()
        if not row:
            row = BlockedIP(ip_address=ip, failed_count=rapid)
            db.add(row)
        row.failed_count = (row.failed_count or 0) + 1
        row.reason = f"هجوم سريع: {rapid} محاولة خلال دقيقتين"
        if row.failed_count >= IP_PERM_AFTER_TEMP_BANS:
            row.permanent = True
            row.blocked_until = None
            result["message"] = "🚫 تم رصد هجوم متكرر. عنوان جهازك محظور بشكل دائم."
            record_security_event(db, "blocked_ip", ip, username, "PERMANENT rapid", "critical")
        else:
            row.blocked_until = utcnow() + timedelta(minutes=IP_TEMP_BAN_MINUTES)
            row.permanent = False
            result["message"] = f"🚫 تم رصد محاولات سريعة مشبوهة. حظر مؤقت {IP_TEMP_BAN_MINUTES} دقيقة."
            record_security_event(db, "blocked_ip", ip, username, "TEMP rapid", "high")
        db.commit()
        result["ip_banned"] = True
        return result

    # --- Slow failures (bad net) — high tolerance ---
    user = db.query(User).filter(User.username == username).first()
    if user:
        user.failed_attempts = (user.failed_attempts or 0) + 1
        if user.failed_attempts >= MAX_FAILED_ACCOUNT_SLOW and not user.is_locked:
            user.is_locked = True
            user.locked_reason = f"قفل بعد {MAX_FAILED_ACCOUNT_SLOW} محاولة فاشلة (IP: {ip})"
            user.locked_at = utcnow()
            user.is_active = False
            result["account_locked"] = True
            result["message"] = "تم قفل الحساب بعد محاولات كثيرة جدًا. تواصل مع الإدارة لإعادة التفعيل."
            record_security_event(db, "locked_account", ip, username, user.locked_reason, "critical")
        db.commit()

    slow = _count_fails(db, ip, minutes=WINDOW_MINUTES)
    if slow >= MAX_FAILED_IP_SLOW:
        row = db.query(BlockedIP).filter(BlockedIP.ip_address == ip).first()
        if not row:
            row = BlockedIP(ip_address=ip, failed_count=slow)
            db.add(row)
        row.failed_count = slow
        row.reason = f"{slow} فشل خلال ساعة"
        row.blocked_until = utcnow() + timedelta(minutes=IP_TEMP_BAN_MINUTES)
        row.permanent = False
        db.commit()
        result["ip_banned"] = True
        result["message"] = f"حظر مؤقت بعد محاولات كثيرة. انتظر {IP_TEMP_BAN_MINUTES} دقيقة."
        record_security_event(db, "blocked_ip", ip, username, "TEMP slow", "high")

    return result

def reset_failed_on_success(db: Session, user: User, ip: str):
    user.failed_attempts = 0
    db.commit()
    record_security_event(db, "successful_login", ip, user.username, "OK", "low")

def check_user_locked(user: Optional[User]) -> Tuple[bool, str]:
    if not user:
        return False, ""
    if user.is_locked or not user.is_active:
        return True, (user.locked_reason or "الحساب مقفل أو معطل. تواصل مع إدارة القطاع.")
    return False, ""

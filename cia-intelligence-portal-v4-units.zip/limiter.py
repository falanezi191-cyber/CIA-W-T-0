"""Shared rate limiter (imported by main.py and routers to avoid circular imports)."""
from slowapi import Limiter
from starlette.requests import Request

from security import get_client_ip


def _key(request: Request) -> str:
    return get_client_ip(request)


limiter = Limiter(key_func=_key)

"""
ER:LC Private Server API v2 client
Docs: https://apidocs.erlc.gg
Fetches every supported live field from GET /v2/server
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import httpx

from config import settings

logger = logging.getLogger("erlc_client")
BASE_URL = "https://api.erlc.gg/v2"

# All known optional query flags for GET /v2/server
ALL_FLAGS = (
    "Players",
    "Staff",
    "JoinLogs",
    "Queue",
    "KillLogs",
    "CommandLogs",
    "ModCalls",
    "EmergencyCalls",
    "Vehicles",
)


class ERLCClient:
    def __init__(self) -> None:
        self.server_key = settings.erlc_server_key
        self._client: Optional[httpx.AsyncClient] = None

    async def start(self) -> None:
        headers = {"server-key": self.server_key or ""}
        self._client = httpx.AsyncClient(base_url=BASE_URL, headers=headers, timeout=20.0)

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    async def fetch_server(self, **flags: bool) -> Dict[str, Any]:
        """
        GET /v2/server with optional includes.
        Pass any of ALL_FLAGS as kwargs (True/False). Default: all True.
        """
        if not self._client:
            raise RuntimeError("Client not started")
        if not self.server_key:
            raise RuntimeError("ERLC_SERVER_KEY not set")

        params = {}
        if not flags:
            for f in ALL_FLAGS:
                params[f] = "true"
        else:
            for f in ALL_FLAGS:
                key = f[0].lower() + f[1:] if False else f  # keep API case
                # accept Players= or players=
                val = flags.get(f, flags.get(f.lower(), True))
                if val:
                    params[f] = "true"

        resp = await self._client.get("/server", params=params)
        resp.raise_for_status()
        data = resp.json()
        data["_fetched_at"] = datetime.now(timezone.utc).isoformat()
        return data

    async def run_command(self, command: str) -> Dict[str, Any]:
        """
        Run in-game command as server management (if pack allows).
        POST /v2/server/command — body depends on API; try common shape.
        """
        if not self._client:
            raise RuntimeError("Client not started")
        command = (command or "").strip()
        if not command:
            raise ValueError("empty command")
        # Official partner clients use runCommand — try v2 command endpoint
        for path, body in (
            ("/server/command", {"command": command}),
            ("/server/commands", {"command": command}),
        ):
            try:
                resp = await self._client.post(path, json=body)
                if resp.status_code < 400:
                    return {"ok": True, "status": resp.status_code, "body": resp.json() if resp.content else {}}
            except Exception as e:
                logger.debug("command try %s: %s", path, e)
        # Fallback: some deployments accept query
        try:
            resp = await self._client.post("/server/command", content=command)
            return {"ok": resp.status_code < 400, "status": resp.status_code, "text": resp.text[:500]}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    @staticmethod
    def parse_player(raw: Dict[str, Any]) -> Dict[str, Any]:
        player_str = raw.get("Player", "") or ""
        name, _, pid = player_str.partition(":")
        loc = raw.get("Location") or {}
        return {
            "id": pid or None,
            "username": name or player_str,
            "raw": player_str,
            "team": raw.get("Team"),
            "callsign": raw.get("Callsign"),
            "permission": raw.get("Permission"),
            "wanted_stars": raw.get("WantedStars", 0),
            "location": {
                "x": loc.get("LocationX"),
                "z": loc.get("LocationZ"),
                "postal": loc.get("PostalCode"),
                "street": loc.get("StreetName"),
                "building": loc.get("BuildingNumber"),
            },
            "has_location": loc.get("LocationX") is not None,
        }

    @staticmethod
    def parse_vehicle(raw: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "name": raw.get("Name"),
            "owner": raw.get("Owner"),
            "plate": raw.get("Plate"),
            "texture": raw.get("Texture"),
            "color_hex": raw.get("ColorHex"),
            "color_name": raw.get("ColorName"),
        }

    @staticmethod
    def parse_join_log(raw: Dict[str, Any]) -> Dict[str, Any]:
        player_str = raw.get("Player", "") or ""
        name, _, pid = player_str.partition(":")
        return {
            "join": bool(raw.get("Join")),
            "timestamp": raw.get("Timestamp"),
            "username": name or player_str,
            "id": pid or None,
        }

    @staticmethod
    def parse_kill_log(raw: Dict[str, Any]) -> Dict[str, Any]:
        killed = raw.get("Killed") or raw.get("Player") or ""
        killer = raw.get("Killer") or ""
        kn, _, kid = str(killed).partition(":")
        kr, _, kid2 = str(killer).partition(":")
        return {
            "killed": kn or killed,
            "killed_id": kid or None,
            "killer": kr or killer,
            "killer_id": kid2 or None,
            "timestamp": raw.get("Timestamp"),
        }

    @staticmethod
    def parse_command_log(raw: Dict[str, Any]) -> Dict[str, Any]:
        player_str = raw.get("Player") or raw.get("Executor") or ""
        name, _, pid = str(player_str).partition(":")
        return {
            "username": name or player_str,
            "id": pid or None,
            "command": raw.get("Command"),
            "timestamp": raw.get("Timestamp"),
        }

    @staticmethod
    def parse_mod_call(raw: Dict[str, Any]) -> Dict[str, Any]:
        caller = raw.get("Caller") or ""
        mod = raw.get("Moderator") or ""
        cn, _, cid = str(caller).partition(":")
        mn, _, mid = str(mod).partition(":")
        return {
            "caller": cn or caller,
            "caller_id": cid or None,
            "moderator": mn or mod,
            "moderator_id": mid or None,
            "timestamp": raw.get("Timestamp"),
        }

    @staticmethod
    def parse_emergency(raw: Dict[str, Any]) -> Dict[str, Any]:
        pos = raw.get("Position") or [None, None]
        return {
            "team": raw.get("Team"),
            "caller": raw.get("Caller"),
            "players": raw.get("Players") or [],
            "x": pos[0] if len(pos) > 0 else None,
            "z": pos[1] if len(pos) > 1 else None,
            "started_at": raw.get("StartedAt"),
            "call_number": raw.get("CallNumber"),
            "description": raw.get("Description"),
            "position_descriptor": raw.get("PositionDescriptor"),
        }

    @staticmethod
    def parse_staff_bucket(raw: Any) -> List[str]:
        if raw is None:
            return []
        if isinstance(raw, list):
            out = []
            for item in raw:
                if isinstance(item, str):
                    out.append(item.split(":")[0])
                elif isinstance(item, dict):
                    p = item.get("Player") or item.get("Name") or str(item)
                    out.append(str(p).split(":")[0])
                else:
                    out.append(str(item))
            return out
        if isinstance(raw, dict):
            # Staff may be {Admins:[], Mods:[], Helpers:[]}
            return raw
        return [str(raw)]

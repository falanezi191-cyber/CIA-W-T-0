"""Account security: 2FA (TOTP), password change, logout-everywhere, audit-chain verify, DB backup."""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

import totp
from config import settings
from database import get_db
from deps import (get_current_user, hash_password, log_action, start_session,
                  verify_audit_chain, verify_password)
from limiter import limiter
from ranks import is_owner_identity, is_supreme

router = APIRouter(tags=["shield"])
templates = Jinja2Templates(directory="templates")
MIN_PW = 12


def _page(request, user, msg=None, err=None, secret=None, uri=None):
    return templates.TemplateResponse("account_security.html", {
        "request": request, "user": user, "msg": msg, "err": err, "secret": secret, "uri": uri,
        "has_password": bool(user.password_hash),
    })


def _strong(pw: str) -> bool:
    return len(pw) >= MIN_PW and any(c.isdigit() for c in pw) and any(c.isalpha() for c in pw)


@router.get("/account/security", response_class=HTMLResponse)
async def account_security(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    return _page(request, user)


@router.post("/account/2fa/setup")
async def twofa_setup(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if user.totp_enabled:
        return _page(request, user, err="التوثيق الثنائي مفعّل مسبقاً")
    user.totp_secret = totp.new_secret()
    db.commit()
    return _page(request, user, secret=user.totp_secret, uri=totp.uri(user.totp_secret, user.username))


@router.post("/account/2fa/enable")
@limiter.limit("10/minute")
async def twofa_enable(request: Request, code: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    step = totp.verify(user.totp_secret, code) if user.totp_secret else None
    if step is None:
        return _page(request, user, err="الرمز غير صحيح، أعد المحاولة",
                     secret=user.totp_secret, uri=totp.uri(user.totp_secret, user.username) if user.totp_secret else None)
    user.totp_enabled, user.totp_last_step = True, step
    db.commit()
    log_action(db, "2fa_enabled", "", user.username)
    return _page(request, user, msg="✅ تم تفعيل التوثيق الثنائي")


@router.post("/account/2fa/disable")
@limiter.limit("5/minute")
async def twofa_disable(request: Request, password: str = Form(""), code: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    ok = totp.verify(user.totp_secret, code, user.totp_last_step or 0) is not None
    if user.password_hash:
        ok = ok and verify_password(password, user.password_hash)
    if not ok:
        return _page(request, user, err="كلمة المرور أو الرمز غير صحيح")
    user.totp_enabled, user.totp_secret = False, ""
    db.commit()
    log_action(db, "2fa_disabled", "", user.username)
    return _page(request, user, msg="تم إيقاف التوثيق الثنائي")


@router.post("/account/password")
@limiter.limit("5/minute")
async def change_password(request: Request, current: str = Form(""), new: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if user.password_hash and not verify_password(current, user.password_hash):
        return _page(request, user, err="كلمة المرور الحالية غير صحيحة")
    if not _strong(new):
        return _page(request, user, err=f"كلمة المرور لازم {MIN_PW} خانة على الأقل وفيها حروف وأرقام")
    user.password_hash = hash_password(new)
    user.session_version = (user.session_version or 0) + 1      # kicks every other device
    db.commit()
    start_session(request, user)
    log_action(db, "password_changed", "all other sessions revoked", user.username)
    return _page(request, user, msg="✅ تم تغيير كلمة المرور وتسجيل الخروج من باقي الأجهزة")


@router.post("/account/logout-all")
async def logout_all(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    user.session_version = (user.session_version or 0) + 1
    db.commit()
    log_action(db, "logout_all", "", user.username)
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


@router.get("/admin/audit/verify")
async def audit_verify(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not (user.is_admin or is_owner_identity(user.username)):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    return verify_audit_chain(db)


@router.get("/admin/backup/db")
async def backup_db(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not is_supreme(user.username):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    if not settings.database_url.startswith("sqlite"):
        return JSONResponse({"error": "use your Postgres provider's backups"}, status_code=400)
    src = Path(settings.database_url.replace("sqlite:///", "", 1))
    tmp = Path(tempfile.mkdtemp()) / "cia-backup.db"
    import sqlite3
    with sqlite3.connect(src) as a, sqlite3.connect(tmp) as b:   # consistent online copy
        a.backup(b)
    log_action(db, "db_backup", "full sqlite download", user.username)
    return FileResponse(tmp, filename="cia-backup.db", media_type="application/octet-stream")

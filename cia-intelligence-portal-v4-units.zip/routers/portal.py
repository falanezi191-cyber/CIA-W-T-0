"""
Portal routes: dashboard, map, tasks, boards, radio, MDT, admin, APIs.
"""
from __future__ import annotations

import json
import secrets
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, Form, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from config import settings
from ai_assistant import chat as ai_local_chat
from database import SessionLocal, get_db
from limiter import limiter
from deps import (
    can_manage_tasks,
    elevate_if_owner,
    get_current_user,
    hash_password,
    is_fully_verified,
    log_action,
    push_site_notif,
)
from models import (
    ActivityLog, AgentNote, Alert, Announcement, Application, Blacklist, BlockedIP,
    Briefing, CaseFile, Commendation, CourtCase, DivisionTask, Document, Evidence,
    Incident, InternalMessage, InventoryItem, LeaveRequest, Meeting, Operation,
    PayrollNote, PersonalTask, RadioChannelLock, RadioLog, RadioMessage, SecurityEvent,
    ShiftNote, SiteNotification, TaskCompletion, TaskTemplate, TrainingRecord, User,
    Watchlist,
)
from notify import notify_bot
from ranks import (
    can_manage_division,
    can_manage_user,
    is_owner_identity,
    is_supreme,
    level as rank_level,
)
import state

router = APIRouter(tags=["portal"])
templates = Jinja2Templates(directory="templates")

DIVISIONS = ("DI", "HR", "FOD", "SOG")
RADIO_MAX = 120
RADIO_RANGE = 450.0
POINTS_PROMOTE = [(50, "Agent"), (120, "Special Agent"), (250, "SAC")]


def _player_pos_by_name(username: str):
    if not username:
        return None
    u = username.lower()
    for p in state.latest_data.get("players") or []:
        name = (p.get("username") or "").lower()
        if name == u or name.startswith(u) or u.startswith(name):
            loc = p.get("location") or {}
            if p.get("has_location") and loc.get("x") is not None:
                return float(loc["x"]), float(loc.get("z") or 0)
    return None


def _dist(a, b):
    if not a or not b:
        return None
    return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5


def radio_allowed(user: User, channel: int, db: Session) -> bool:
    if channel < 1 or channel > RADIO_MAX:
        return False
    if is_supreme(user.username) or is_owner_identity(user.username) or user.is_admin:
        return True
    lock = (
        db.query(RadioChannelLock)
        .filter(RadioChannelLock.channel == channel, RadioChannelLock.locked == True)
        .first()
    )
    if not lock:
        return True
    ranks = [x.strip() for x in (lock.allowed_ranks or "").split(",") if x.strip()]
    return user.rank in ranks



def _ws_user(ws: WebSocket):
    """Authenticate a WebSocket via the signed session cookie (SessionMiddleware covers websockets)."""
    uid = ws.session.get("user_id") if "session" in ws.scope else None
    if not uid:
        return None
    db = SessionLocal()
    try:
        u = db.query(User).filter(User.id == uid, User.is_active == True).first()
        if u:
            db.expunge(u)
        return u
    finally:
        db.close()


def _ws_origin_ok(ws: WebSocket) -> bool:
    from urllib.parse import urlparse
    origin = ws.headers.get("origin")
    if not origin:
        return True
    host = ws.headers.get("x-forwarded-host") or ws.headers.get("host") or ""
    return urlparse(origin).netloc == host


# ── Main Pages ───────────────────────────────────────────
@router.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    agents = db.query(User).filter(User.is_active == True).count()
    pending = db.query(Application).filter(Application.status == "pending").count()
    blacklist_count = db.query(Blacklist).count()
    recent_logs = db.query(ActivityLog).order_by(ActivityLog.created_at.desc()).limit(10).all()
    announcements = db.query(Announcement).order_by(Announcement.created_at.desc()).limit(5).all()
    on_duty = db.query(User).filter(User.duty_status == "on", User.is_active == True).count()
    return templates.TemplateResponse("dashboard.html", {
        "request": request, "user": user,
        "agents": agents, "pending": pending, "blacklist_count": blacklist_count,
        "recent_logs": recent_logs, "live": state.latest_data,
        "announcements": announcements, "on_duty": on_duty,
    })

@router.get("/map", response_class=HTMLResponse)
async def map_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_map and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    return templates.TemplateResponse("map.html", {
        "request": request, "user": user,
        "map_size": settings.map_size, "map_scale": settings.map_scale,
    })

@router.get("/personnel", response_class=HTMLResponse)
async def personnel(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_personnel and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    agents = db.query(User).order_by(User.rank, User.display_name).all()
    return templates.TemplateResponse("personnel.html", {"request": request, "user": user, "agents": agents})

@router.get("/applications", response_class=HTMLResponse)
async def applications_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_applications and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    apps = db.query(Application).order_by(Application.created_at.desc()).all()
    can_manage = user.can_manage_applications or user.is_admin
    return templates.TemplateResponse("applications.html", {
        "request": request, "user": user, "apps": apps, "can_manage": can_manage
    })

@router.post("/applications/{app_id}/review")
async def review_app(app_id: int, request: Request, status: str = Form(...), note: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.can_manage_applications and not user.is_admin):
        return RedirectResponse("/applications", status_code=303)
    if status not in ("accepted", "rejected"):
        return RedirectResponse("/applications", status_code=303)
    app = db.query(Application).filter(Application.id == app_id).first()
    if app:
        app.status = status
        app.reviewer_note = note[:500]
        app.reviewed_by = user.username
        app.reviewed_at = datetime.now(timezone.utc)
        db.commit()
        log_action(db, "review_application", f"{status} app #{app_id}", user.username)
        applicant = db.query(User).filter(User.id == app.user_id).first() if app.user_id else None
        if status == "accepted" and applicant:
            # 1) local portal access
            from config import ROLE_MAP
            from routers.auth import apply_role_permissions
            if not (settings.discord_accepted_role_id and apply_role_permissions(applicant, [settings.discord_accepted_role_id])):
                applicant.rank, applicant.clearance = "Agent", "Confidential"
                applicant.can_view_map = applicant.can_view_vehicles = True
                applicant.can_view_applications = False
            db.commit()
            # 2) Discord server: give the member role, drop the applicant role, set nickname
            import discord_api
            from routers.linking import nick_for
            res = await discord_api.sync_member(
                app.discord_id or applicant.discord_id or "",
                add_roles=[settings.discord_accepted_role_id],
                remove_roles=[settings.discord_applicant_role_id] if settings.discord_accepted_role_id else [],
                nick=nick_for(applicant), reason=f"Application accepted by {user.username}",
            )
            log_action(db, "discord_sync", f"{applicant.username}: {'ok' if res['ok'] else res['errors']}", user.username)
        # Notify Discord bot (separate process)
        event = "application_accepted" if status == "accepted" else "application_rejected"
        portal = getattr(settings, "discord_redirect_uri", "") or ""
        base = portal.replace("/auth/discord/callback", "") if portal else ""
        msg_extra = f"\nالبوابة: {base}/applications" if base else ""
        await notify_bot({
            "type": event,
            "discord": app.discord or "",
            "name": app.full_name,
            "reason": note[:300] if status == "rejected" else "",
            "message": (f"✅ تم قبول تقديمك — ادخل البوابة لاستلام صلاحياتك{msg_extra}" if status == "accepted"
                        else f"❌ تم رفض التقديم{(': ' + note[:200]) if note else ''}{msg_extra}"),
        })
        if app.discord:
            await push_site_notif(db, app.discord.split("#")[0][:64], 
                "قبول التقديم" if status=="accepted" else "رفض التقديم",
                note[:200] if note else app.full_name, "/applications")
    return RedirectResponse("/applications", status_code=303)

@router.get("/id-card", response_class=HTMLResponse)
async def id_card_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    target = user
    target_id = request.query_params.get("uid")
    if target_id and (user.can_issue_id or user.is_admin):
        t = db.query(User).filter(User.id == int(target_id)).first()
        if t:
            target = t
    return templates.TemplateResponse("id_card.html", {"request": request, "user": user, "agent": target})

@router.get("/blacklist", response_class=HTMLResponse)
async def blacklist_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_manage_blacklist and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    items = db.query(Blacklist).order_by(Blacklist.created_at.desc()).all()
    return templates.TemplateResponse("blacklist.html", {"request": request, "user": user, "items": items})

@router.post("/blacklist/add")
async def add_blacklist(request: Request, username: str = Form(...), roblox_id: str = Form(""), reason: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.can_manage_blacklist and not user.is_admin):
        return RedirectResponse("/blacklist", status_code=303)
    db.add(Blacklist(username=username[:64], roblox_id=roblox_id[:30], reason=reason[:500], added_by=user.username))
    db.commit()
    log_action(db, "blacklist_add", username, user.username)
    return RedirectResponse("/blacklist", status_code=303)

@router.get("/logs", response_class=HTMLResponse)
async def logs_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_logs and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    logs = db.query(ActivityLog).order_by(ActivityLog.created_at.desc()).limit(100).all()
    return templates.TemplateResponse("logs.html", {"request": request, "user": user, "logs": logs})

@router.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    users = db.query(User).order_by(User.id).all()
    return templates.TemplateResponse("admin.html", {"request": request, "user": user, "users": users})

@router.post("/admin/user")
async def create_or_update_user(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse("/admin", status_code=303)
    form = await request.form()
    uid = form.get("user_id")
    if uid:
        target = db.query(User).filter(User.id == int(uid)).first() if str(uid).isdigit() else None
        if not target:
            return RedirectResponse("/admin", status_code=303)
        # Hierarchy protection: cannot demote/lock equal or higher (esp. ministers)
        if not can_manage_user(user.rank, user.is_admin, target.rank, target.is_admin, user.username, target.username):
            log_action(db, "admin_denied", f"Blocked edit on {target.username}", user.username)
            return RedirectResponse("/admin", status_code=303)
    else:
        uname = (form.get("username") or "").strip()
        if not uname:
            return RedirectResponse("/admin", status_code=303)
        if db.query(User).filter(User.username == uname[:64]).first() or (
            is_owner_identity(uname) and not (is_supreme(user.username) or is_owner_identity(user.username))
        ):
            log_action(db, "admin_denied", f"Blocked create of {uname}", user.username)
            return RedirectResponse("/admin", status_code=303)
        target = User(username=uname[:64], password_hash=hash_password(form.get("password") or secrets.token_urlsafe(8)))
        db.add(target)

    new_rank = (form.get("rank") or "Recruit")[:50]
    wants_admin = form.get("is_admin") == "on"
    actor_is_owner = is_supreme(user.username) or is_owner_identity(user.username)
    # Nobody can grant a rank at/above their own (or make admins) unless they are an Owner.
    if not actor_is_owner and (rank_level(new_rank) >= rank_level(user.rank) or (wants_admin and not target.is_admin)):
        log_action(db, "admin_denied", f"Blocked escalation on {target.username} -> {new_rank}", user.username)
        db.rollback()
        return RedirectResponse("/admin", status_code=303)
    target.display_name = (form.get("display_name") or target.username)[:100]
    target.rank = new_rank
    target.clearance = (form.get("clearance") or "Confidential")[:20]
    target.callsign = (form.get("callsign") or "")[:30]
    target.roblox_id = (form.get("roblox_id") or "")[:30]
    target.is_active = form.get("is_active") == "on"
    target.is_admin = form.get("is_admin") == "on"
    target.can_view_map = form.get("can_view_map") == "on"
    target.can_view_personnel = form.get("can_view_personnel") == "on"
    target.can_manage_personnel = form.get("can_manage_personnel") == "on"
    target.can_view_applications = form.get("can_view_applications") == "on"
    target.can_manage_applications = form.get("can_manage_applications") == "on"
    target.can_issue_id = form.get("can_issue_id") == "on"
    target.can_view_logs = form.get("can_view_logs") == "on"
    target.can_manage_blacklist = form.get("can_manage_blacklist") == "on"
    target.can_view_vehicles = form.get("can_view_vehicles") == "on"
    if form.get("password"):
        target.password_hash = hash_password(form.get("password"))
    db.commit()
    log_action(db, "admin_user_update", f"User {target.username}", user.username)
    return RedirectResponse("/admin", status_code=303)




# ── Extra features ───────────────────────────────────────
@router.post("/duty/toggle")
async def duty_toggle(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    user.duty_status = "off" if user.duty_status == "on" else "on"
    db.commit()
    log_action(db, "duty_toggle", user.duty_status, user.username)
    return RedirectResponse("/", status_code=303)

@router.post("/announcements/add")
async def add_announcement(request: Request, title: str = Form(...), body: str = Form(""), priority: str = Form("normal"), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and not is_owner_identity(user.username)):
        return RedirectResponse("/", status_code=303)
    db.add(Announcement(title=title[:120], body=body[:2000], priority=priority[:20], author=user.username))
    db.commit()
    log_action(db, "announcement", title[:80], user.username)
    await notify_bot({
        "type": "announcement",
        "title": title[:120],
        "body": body[:1500],
        "priority": priority[:20],
    })
    return RedirectResponse("/", status_code=303)

@router.post("/profile/codename")
async def set_codename(request: Request, codename: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    user.codename = (codename or "")[:40]
    db.commit()
    return RedirectResponse("/id-card", status_code=303)

# ── Security Center (Director / Minister) ────────────────
@router.get("/security", response_class=HTMLResponse)
async def security_center(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.is_admin and rank_level(user.rank) < 90 and not is_owner_identity(user.username):
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    events = db.query(SecurityEvent).order_by(SecurityEvent.created_at.desc()).limit(50).all()
    blocked = db.query(BlockedIP).order_by(BlockedIP.created_at.desc()).all()
    locked_users = db.query(User).filter((User.is_locked == True) | (User.is_active == False)).all()
    return templates.TemplateResponse("security.html", {
        "request": request, "user": user,
        "events": events, "blocked": blocked, "locked_users": locked_users,
    })

@router.post("/security/unlock-user/{uid}")
async def unlock_user(uid: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 90):
        return RedirectResponse("/security", status_code=303)
    target = db.query(User).filter(User.id == uid).first()
    if target and can_manage_user(user.rank, user.is_admin, target.rank, target.is_admin, user.username, target.username):
        target.is_locked = False
        target.is_active = True
        target.failed_attempts = 0
        target.locked_reason = ""
        db.commit()
        log_action(db, "unlock_user", target.username, user.username)
    return RedirectResponse("/security", status_code=303)

@router.post("/security/unblock-ip/{ip_id}")
async def unblock_ip(ip_id: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 90):
        return RedirectResponse("/security", status_code=303)
    row = db.query(BlockedIP).filter(BlockedIP.id == ip_id).first()
    if row:
        db.delete(row)
        db.commit()
        log_action(db, "unblock_ip", row.ip_address, user.username)
    return RedirectResponse("/security", status_code=303)

# ── AI Assistant ─────────────────────────────────────────
@router.get("/ai", response_class=HTMLResponse)
async def ai_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse("ai.html", {"request": request, "user": user})

@router.post("/api/ai/chat")
@limiter.limit("20/minute")
async def ai_chat_api(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "bad request"}, status_code=400)
    message = (body.get("message") or "").strip()
    history = body.get("history") or []
    if not message or len(message) > 2000:
        return JSONResponse({"error": "invalid message"}, status_code=400)
    if not isinstance(history, list):
        history = []
    history = [m for m in history[-6:] if isinstance(m, dict)]
    reply = ai_local_chat(history, message)
    return {"reply": reply}


# ── Cases ────────────────────────────────────────────────
@router.get("/cases", response_class=HTMLResponse)
async def cases_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_logs and not user.is_admin and rank_level(user.rank) < 40:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    cases = db.query(CaseFile).order_by(CaseFile.created_at.desc()).limit(100).all()
    return templates.TemplateResponse("cases.html", {"request": request, "user": user, "cases": cases})

@router.post("/cases/add")
async def cases_add(request: Request, title: str = Form(...), classification: str = Form("Confidential"),
                    summary: str = Form(""), lead_agent: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 40):
        return RedirectResponse("/cases", status_code=303)
    code = "CASE-" + secrets.token_hex(3).upper()
    db.add(CaseFile(case_code=code, title=title[:150], classification=classification[:20],
                    summary=summary[:3000], lead_agent=lead_agent[:64], created_by=user.username))
    db.commit()
    log_action(db, "case_open", code + " " + title[:40], user.username)
    return RedirectResponse("/cases", status_code=303)

@router.post("/cases/{cid}/status")
async def cases_status(cid: int, request: Request, status: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    c = db.query(CaseFile).filter(CaseFile.id == cid).first()
    if c and status in ("open", "active", "closed", "archived"):
        c.status = status
        c.updated_at = datetime.now(timezone.utc)
        db.commit()
    return RedirectResponse("/cases", status_code=303)

# ── Operations ───────────────────────────────────────────
@router.get("/operations", response_class=HTMLResponse)
async def operations_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_map and not user.is_admin and rank_level(user.rank) < 40:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    ops = db.query(Operation).order_by(Operation.created_at.desc()).limit(80).all()
    return templates.TemplateResponse("operations.html", {"request": request, "user": user, "ops": ops})

@router.post("/operations/add")
async def operations_add(request: Request, title: str = Form(...), location: str = Form(""),
                         commander: str = Form(""), details: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 50):
        return RedirectResponse("/operations", status_code=303)
    code = "OP-" + secrets.token_hex(2).upper()
    db.add(Operation(op_code=code, title=title[:150], location=location[:100],
                     commander=commander[:64] or user.username, details=details[:3000], created_by=user.username))
    db.commit()
    log_action(db, "op_create", code, user.username)
    return RedirectResponse("/operations", status_code=303)

@router.post("/operations/{oid}/status")
async def operations_status(oid: int, request: Request, status: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    op = db.query(Operation).filter(Operation.id == oid).first()
    if op and status in ("planned", "live", "completed", "cancelled"):
        op.status = status
        db.commit()
        if status == "live":
            await notify_bot({"type": "custom", "message": f"🚨 عملية مباشرة: {op.op_code} — {op.title}"})
    return RedirectResponse("/operations", status_code=303)

# ── Documents / SOP ──────────────────────────────────────
@router.get("/documents", response_class=HTMLResponse)
async def documents_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    docs = db.query(Document).order_by(Document.created_at.desc()).all()
    return templates.TemplateResponse("documents.html", {"request": request, "user": user, "docs": docs})

@router.post("/documents/add")
async def documents_add(request: Request, title: str = Form(...), category: str = Form("SOP"),
                        classification: str = Form("Restricted"), body: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 80):
        return RedirectResponse("/documents", status_code=303)
    db.add(Document(title=title[:150], category=category[:40], classification=classification[:20],
                    body=body[:8000], author=user.username))
    db.commit()
    return RedirectResponse("/documents", status_code=303)

# ── Command structure ────────────────────────────────────
@router.get("/command", response_class=HTMLResponse)
async def command_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    agents = db.query(User).filter(User.is_active == True).order_by(User.rank).all()
    # group by rank level roughly
    return templates.TemplateResponse("command.html", {"request": request, "user": user, "agents": agents})

# ── Commendations ────────────────────────────────────────
@router.get("/records", response_class=HTMLResponse)
async def records_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_personnel and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    items = db.query(Commendation).order_by(Commendation.created_at.desc()).limit(100).all()
    training = db.query(TrainingRecord, Evidence, Watchlist, AgentNote, ShiftNote, Alert, Meeting, InventoryItem).order_by(TrainingRecord, Evidence, Watchlist, AgentNote, ShiftNote, Alert, Meeting, InventoryItem.created_at.desc()).limit(50).all()
    return templates.TemplateResponse("records.html", {"request": request, "user": user, "items": items, "training": training})

@router.post("/records/commend")
async def records_commend(request: Request, target_username: str = Form(...), kind: str = Form("commend"),
                          reason: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 60):
        return RedirectResponse("/records", status_code=303)
    if kind not in ("commend", "warning", "strike"):
        kind = "commend"
    db.add(Commendation(target_username=target_username[:64], kind=kind, reason=reason[:1000], issued_by=user.username))
    db.commit()
    log_action(db, "record_" + kind, target_username, user.username)
    if kind == "commend":
        await notify_bot({"type": "custom", "discord": target_username, "message": f"🏅 تكريم من القطاع: {reason[:200]}"})
    elif kind == "strike":
        await notify_bot({"type": "custom", "discord": target_username, "message": f"⚠️ إنذار مسجّل: {reason[:200]}"})
    return RedirectResponse("/records", status_code=303)

@router.post("/records/training")
async def records_training(request: Request, agent_username: str = Form(...), course: str = Form(...),
                           status: str = Form("completed"), score: str = Form(""), notes: str = Form(""),
                           db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 50):
        return RedirectResponse("/records", status_code=303)
    db.add(TrainingRecord, Evidence, Watchlist, AgentNote, ShiftNote, Alert, Meeting, InventoryItem(agent_username=agent_username[:64], course=course[:100], status=status[:20],
                          score=score[:20], notes=notes[:500], instructor=user.username))
    db.commit()
    return RedirectResponse("/records", status_code=303)

# ── Internal mail ────────────────────────────────────────
@router.get("/mail", response_class=HTMLResponse)
async def mail_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    inbox = db.query(InternalMessage).filter(InternalMessage.to_username == user.username).order_by(InternalMessage.created_at.desc()).limit(50).all()
    sent = db.query(InternalMessage).filter(InternalMessage.from_username == user.username).order_by(InternalMessage.created_at.desc()).limit(30).all()
    return templates.TemplateResponse("mail.html", {"request": request, "user": user, "inbox": inbox, "sent": sent})

@router.post("/mail/send")
async def mail_send(request: Request, to_username: str = Form(...), subject: str = Form(""), body: str = Form(""),
                    db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    db.add(InternalMessage(to_username=to_username[:64], from_username=user.username,
                           subject=subject[:150], body=body[:4000]))
    db.commit()
    return RedirectResponse("/mail", status_code=303)

@router.post("/mail/{mid}/read")
async def mail_read(mid: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    msg = db.query(InternalMessage).filter(InternalMessage.id == mid, InternalMessage.to_username == user.username).first()
    if msg:
        msg.is_read = True
        db.commit()
    return RedirectResponse("/mail", status_code=303)


# ── Evidence / Watchlist / Notes / Shifts / Alerts / Meetings / Inventory / Modules
@router.get("/modules", response_class=HTMLResponse)
async def modules_hub(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse("modules.html", {"request": request, "user": user})

@router.get("/evidence", response_class=HTMLResponse)
async def evidence_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    items = db.query(Evidence).order_by(Evidence.created_at.desc()).limit(100).all()
    return templates.TemplateResponse("evidence.html", {"request": request, "user": user, "items": items})

@router.post("/evidence/add")
async def evidence_add(request: Request, title: str = Form(...), case_code: str = Form(""), description: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    code = "EV-" + secrets.token_hex(2).upper()
    db.add(Evidence(code=code, title=title[:150], case_code=case_code[:30], description=description[:2000], stored_by=user.username))
    db.commit()
    return RedirectResponse("/evidence", status_code=303)

@router.get("/watchlist", response_class=HTMLResponse)
async def watchlist_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    items = db.query(Watchlist).order_by(Watchlist.created_at.desc()).all()
    return templates.TemplateResponse("watchlist.html", {"request": request, "user": user, "items": items})

@router.post("/watchlist/add")
async def watchlist_add(request: Request, subject: str = Form(...), reason: str = Form(""), level: str = Form("observe"), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 40):
        return RedirectResponse("/watchlist", status_code=303)
    db.add(Watchlist(subject=subject[:100], reason=reason[:1000], level=level[:20], added_by=user.username))
    db.commit()
    return RedirectResponse("/watchlist", status_code=303)

@router.get("/shifts", response_class=HTMLResponse)
async def shifts_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    notes = db.query(ShiftNote).order_by(ShiftNote.created_at.desc()).limit(40).all()
    on_duty = db.query(User).filter(User.duty_status == "on", User.is_active == True).all()
    return templates.TemplateResponse("shifts.html", {"request": request, "user": user, "notes": notes, "on_duty": on_duty})

@router.post("/shifts/add")
async def shifts_add(request: Request, shift_date: str = Form(""), content: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    db.add(ShiftNote(shift_date=shift_date[:20], content=content[:3000], author=user.username))
    db.commit()
    return RedirectResponse("/shifts", status_code=303)

@router.get("/alerts", response_class=HTMLResponse)
async def alerts_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    items = db.query(Alert).order_by(Alert.created_at.desc()).limit(30).all()
    return templates.TemplateResponse("alerts.html", {"request": request, "user": user, "items": items})

@router.post("/alerts/add")
async def alerts_add(request: Request, title: str = Form(...), body: str = Form(""), level: str = Form("info"), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and not is_owner_identity(user.username)):
        return RedirectResponse("/alerts", status_code=303)
    db.add(Alert(title=title[:150], body=body[:2000], level=level[:20], created_by=user.username))
    db.commit()
    await notify_bot({"type": "custom", "message": f"[{level.upper()}] {title}\n{body[:300]}"})
    return RedirectResponse("/alerts", status_code=303)

@router.post("/alerts/{aid}/off")
async def alerts_off(aid: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse("/alerts", status_code=303)
    a = db.query(Alert).filter(Alert.id == aid).first()
    if a:
        a.active = False
        db.commit()
    return RedirectResponse("/alerts", status_code=303)

@router.get("/meetings", response_class=HTMLResponse)
async def meetings_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    items = db.query(Meeting).order_by(Meeting.created_at.desc()).limit(40).all()
    return templates.TemplateResponse("meetings.html", {"request": request, "user": user, "items": items})

@router.post("/meetings/add")
async def meetings_add(request: Request, title: str = Form(...), when_text: str = Form(""), location: str = Form(""), notes: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 50):
        return RedirectResponse("/meetings", status_code=303)
    db.add(Meeting(title=title[:150], when_text=when_text[:80], location=location[:100], notes=notes[:2000], created_by=user.username))
    db.commit()
    return RedirectResponse("/meetings", status_code=303)

@router.get("/inventory", response_class=HTMLResponse)
async def inventory_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    items = db.query(InventoryItem).order_by(InventoryItem.created_at.desc()).all()
    return templates.TemplateResponse("inventory.html", {"request": request, "user": user, "items": items})

@router.post("/inventory/add")
async def inventory_add(request: Request, name: str = Form(...), qty: str = Form("1"), category: str = Form("gear"), assigned_to: str = Form(""), notes: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 40):
        return RedirectResponse("/inventory", status_code=303)
    db.add(InventoryItem(name=name[:100], qty=qty[:20], category=category[:40], assigned_to=assigned_to[:64], notes=notes[:500], updated_by=user.username))
    db.commit()
    return RedirectResponse("/inventory", status_code=303)

@router.get("/notes", response_class=HTMLResponse)
async def notes_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_personnel and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    items = db.query(AgentNote).order_by(AgentNote.created_at.desc()).limit(80).all()
    return templates.TemplateResponse("notes.html", {"request": request, "user": user, "items": items})

@router.post("/notes/add")
async def notes_add(request: Request, about_username: str = Form(...), note: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.can_view_personnel and not user.is_admin):
        return RedirectResponse("/notes", status_code=303)
    db.add(AgentNote(about_username=about_username[:64], note=note[:2000], author=user.username))
    db.commit()
    return RedirectResponse("/notes", status_code=303)


# ── Radio / Incidents / HR leave / Payroll / Court / Briefings ──
@router.get("/radio", response_class=HTMLResponse)
async def radio_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    logs = db.query(RadioLog).order_by(RadioLog.created_at.desc()).limit(60).all()
    return templates.TemplateResponse("radio.html", {"request": request, "user": user, "logs": logs})

@router.post("/radio/send")
async def radio_send(request: Request, channel: str = Form("TAC-1"), message: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    db.add(RadioLog(channel=channel[:40], message=message[:500], author=user.username))
    db.commit()
    return RedirectResponse("/radio", status_code=303)

@router.get("/incidents", response_class=HTMLResponse)
async def incidents_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    items = db.query(Incident).order_by(Incident.created_at.desc()).limit(80).all()
    return templates.TemplateResponse("incidents.html", {"request": request, "user": user, "items": items})

@router.post("/incidents/add")
async def incidents_add(request: Request, title: str = Form(...), postal: str = Form(""), severity: str = Form("medium"), details: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    code = "INC-" + secrets.token_hex(2).upper()
    db.add(Incident(code=code, title=title[:150], postal=postal[:20], severity=severity[:20], details=details[:2000], reported_by=user.username))
    db.commit()
    await notify_bot({"type": "custom", "message": f"🚨 بلاغ {code}: {title} @ {postal or '?'}"})
    return RedirectResponse("/incidents", status_code=303)

@router.post("/incidents/{iid}/status")
async def incidents_status(iid: int, request: Request, status: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    item = db.query(Incident).filter(Incident.id == iid).first()
    if item and status in ("open", "responding", "resolved", "closed"):
        item.status = status
        db.commit()
    return RedirectResponse("/incidents", status_code=303)

@router.get("/hr", response_class=HTMLResponse)
async def hr_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    leaves = db.query(LeaveRequest).order_by(LeaveRequest.created_at.desc()).limit(50).all()
    payroll = db.query(PayrollNote).order_by(PayrollNote.created_at.desc()).limit(50).all()
    return templates.TemplateResponse("hr.html", {"request": request, "user": user, "leaves": leaves, "payroll": payroll})

@router.post("/hr/leave")
async def hr_leave(request: Request, leave_type: str = Form("leave"), from_date: str = Form(""), to_date: str = Form(""), reason: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    db.add(LeaveRequest(username=user.username, leave_type=leave_type[:30], from_date=from_date[:20], to_date=to_date[:20], reason=reason[:1000]))
    db.commit()
    return RedirectResponse("/hr", status_code=303)

@router.post("/hr/leave/{lid}/review")
async def hr_leave_review(lid: int, request: Request, status: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and user.rank != "HR" and rank_level(user.rank) < 80):
        return RedirectResponse("/hr", status_code=303)
    row = db.query(LeaveRequest).filter(LeaveRequest.id == lid).first()
    if row and status in ("accepted", "rejected"):
        row.status = status
        row.reviewed_by = user.username
        db.commit()
        await notify_bot({"type": "custom", "discord": row.username, "message": f"طلب إجازة: {status}"})
    return RedirectResponse("/hr", status_code=303)

@router.post("/hr/payroll")
async def hr_payroll(request: Request, username: str = Form(...), amount: str = Form(""), period: str = Form(""), note: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and user.rank != "HR" and rank_level(user.rank) < 90):
        return RedirectResponse("/hr", status_code=303)
    db.add(PayrollNote(username=username[:64], amount=amount[:30], period=period[:40], note=note[:500], issued_by=user.username))
    db.commit()
    return RedirectResponse("/hr", status_code=303)

@router.get("/court", response_class=HTMLResponse)
async def court_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    items = db.query(CourtCase).order_by(CourtCase.created_at.desc()).limit(50).all()
    return templates.TemplateResponse("court.html", {"request": request, "user": user, "items": items})

@router.post("/court/add")
async def court_add(request: Request, title: str = Form(...), defendant: str = Form(""), notes: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 50):
        return RedirectResponse("/court", status_code=303)
    code = "CRT-" + secrets.token_hex(2).upper()
    db.add(CourtCase(code=code, title=title[:150], defendant=defendant[:100], notes=notes[:2000], created_by=user.username))
    db.commit()
    return RedirectResponse("/court", status_code=303)

@router.post("/court/{cid}/verdict")
async def court_verdict(cid: int, request: Request, status: str = Form(...), verdict: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 60):
        return RedirectResponse("/court", status_code=303)
    row = db.query(CourtCase).filter(CourtCase.id == cid).first()
    if row:
        row.status = status[:20]
        row.verdict = verdict[:2000]
        db.commit()
    return RedirectResponse("/court", status_code=303)

@router.get("/briefing", response_class=HTMLResponse)
async def briefing_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    items = db.query(Briefing).order_by(Briefing.created_at.desc()).limit(30).all()
    return templates.TemplateResponse("briefing.html", {"request": request, "user": user, "items": items})

@router.post("/briefing/add")
async def briefing_add(request: Request, title: str = Form(...), body: str = Form(""), shift: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 40):
        return RedirectResponse("/briefing", status_code=303)
    db.add(Briefing(title=title[:150], body=body[:4000], shift=shift[:40], author=user.username))
    db.commit()
    await notify_bot({"type": "announcement", "title": "Briefing: " + title[:80], "body": body[:400], "priority": "high"})
    return RedirectResponse("/briefing", status_code=303)


# ── Daily / Division / Personal Tasks ────────────────────


@router.get("/tasks", response_class=HTMLResponse)
async def tasks_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    division = (request.query_params.get("div") or "ALL").upper()
    show_archive = request.query_params.get("archive") == "1"
    q = db.query(DivisionTask).order_by(DivisionTask.task_date.desc(), DivisionTask.id.desc())
    if division in DIVISIONS:
        q = q.filter(DivisionTask.division == division)
    if show_archive:
        q = q.filter(DivisionTask.status.in_(["done", "cancelled"]))
    else:
        q = q.filter(DivisionTask.status.in_(["pending", "in_progress"]))
    div_tasks = q.limit(100).all()
    # completion stats per division (active day scope: all non-cancelled)
    stats = {}
    for d in DIVISIONS:
        total = db.query(DivisionTask).filter(DivisionTask.division == d, DivisionTask.status != "cancelled").count()
        done = db.query(DivisionTask).filter(DivisionTask.division == d, DivisionTask.status == "done").count()
        stats[d] = {"total": total, "done": done, "pct": int(100 * done / total) if total else 0}

    my_tasks = db.query(PersonalTask).filter(PersonalTask.assigned_to == user.username).order_by(PersonalTask.id.desc()).limit(50).all()
    all_personal = []
    if can_manage_tasks(user):
        all_personal = db.query(PersonalTask).order_by(PersonalTask.id.desc()).limit(80).all()
    agents = db.query(User).filter(User.is_active == True).order_by(User.username).all()
    return templates.TemplateResponse("tasks.html", {
        "request": request, "user": user,
        "div_tasks": div_tasks, "my_tasks": my_tasks, "all_personal": all_personal,
        "division": division, "divisions": DIVISIONS, "agents": agents,
        "can_manage": can_manage_tasks(user),
        "show_archive": show_archive, "stats": stats,
    })

@router.post("/tasks/division/add")
async def tasks_div_add(request: Request, division: str = Form(...), title: str = Form(...),
                        description: str = Form(""), task_date: str = Form(""), priority: str = Form("normal"),
                        db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    div = division.upper().strip()
    if not user or (not can_manage_tasks(user) and not can_manage_division(user.rank, user.username, div, user.is_admin)):
        return RedirectResponse("/tasks", status_code=303)
    if div not in DIVISIONS:
        return RedirectResponse("/tasks", status_code=303)
    db.add(DivisionTask(
        division=div, title=title[:150], description=description[:2000],
        task_date=task_date[:20], priority=priority[:20],
        created_by=user.username, updated_by=user.username,
    ))
    db.commit()
    log_action(db, "task_div_add", f"{div}: {title[:40]}", user.username)
    return RedirectResponse(f"/tasks?div={div}", status_code=303)

@router.post("/tasks/division/{tid}/edit")
async def tasks_div_edit(tid: int, request: Request, title: str = Form(...), description: str = Form(""),
                         task_date: str = Form(""), priority: str = Form("normal"), status: str = Form("pending"),
                         db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not can_manage_tasks(user):
        return RedirectResponse("/tasks", status_code=303)
    row = db.query(DivisionTask).filter(DivisionTask.id == tid).first()
    if row:
        row.title = title[:150]
        row.description = description[:2000]
        row.task_date = task_date[:20]
        row.priority = priority[:20]
        if status in ("pending", "in_progress", "done", "cancelled"):
            row.status = status
        row.updated_by = user.username
        row.updated_at = datetime.now(timezone.utc)
        db.commit()
    return RedirectResponse("/tasks", status_code=303)

@router.post("/tasks/division/{tid}/status")
async def tasks_div_status(tid: int, request: Request, status: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    row = db.query(DivisionTask).filter(DivisionTask.id == tid).first()
    if row and status in ("pending", "in_progress", "done", "cancelled"):
        # members can mark progress; only leaders cancel/delete path
        if status == "cancelled" and not can_manage_tasks(user):
            return RedirectResponse("/tasks", status_code=303)
        row.status = status
        row.updated_by = user.username
        row.updated_at = datetime.now(timezone.utc)
        db.commit()
    return RedirectResponse("/tasks", status_code=303)

@router.post("/tasks/division/{tid}/delete")
async def tasks_div_delete(tid: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not can_manage_tasks(user):
        return RedirectResponse("/tasks", status_code=303)
    row = db.query(DivisionTask).filter(DivisionTask.id == tid).first()
    if row:
        db.delete(row)
        db.commit()
        log_action(db, "task_div_del", str(tid), user.username)
    return RedirectResponse("/tasks", status_code=303)

@router.post("/tasks/personal/add")
async def tasks_personal_add(request: Request, assigned_to: str = Form(...), title: str = Form(...),
                             description: str = Form(""), task_date: str = Form(""), priority: str = Form("normal"),
                             db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not can_manage_tasks(user):
        return RedirectResponse("/tasks", status_code=303)
    db.add(PersonalTask(
        assigned_to=assigned_to[:64], title=title[:150], description=description[:2000],
        task_date=task_date[:20], priority=priority[:20],
        created_by=user.username, updated_by=user.username,
    ))
    db.commit()
    log_action(db, "task_personal_add", f"{assigned_to}: {title[:40]}", user.username)
    await notify_bot({"type": "custom", "discord": assigned_to, "message": f"📋 مهمة جديدة من القيادة: {title[:120]}\nافتح: المهام في البوابة"})
    await push_site_notif(db, assigned_to, "مهمة جديدة", title[:120], "/tasks")
    return RedirectResponse("/tasks", status_code=303)

@router.post("/tasks/personal/{tid}/edit")
async def tasks_personal_edit(tid: int, request: Request, title: str = Form(...), description: str = Form(""),
                              task_date: str = Form(""), priority: str = Form("normal"), status: str = Form("pending"),
                              assigned_to: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not can_manage_tasks(user):
        return RedirectResponse("/tasks", status_code=303)
    row = db.query(PersonalTask).filter(PersonalTask.id == tid).first()
    if row:
        row.title = title[:150]
        row.description = description[:2000]
        row.task_date = task_date[:20]
        row.priority = priority[:20]
        if assigned_to:
            row.assigned_to = assigned_to[:64]
        if status in ("pending", "in_progress", "done", "cancelled"):
            row.status = status
        row.updated_by = user.username
        row.updated_at = datetime.now(timezone.utc)
        db.commit()
    return RedirectResponse("/tasks", status_code=303)

@router.post("/tasks/personal/{tid}/status")
async def tasks_personal_status(tid: int, request: Request, status: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    row = db.query(PersonalTask).filter(PersonalTask.id == tid).first()
    if not row:
        return RedirectResponse("/tasks", status_code=303)
    # assignee or leadership
    if row.assigned_to != user.username and not can_manage_tasks(user):
        return RedirectResponse("/tasks", status_code=303)
    if status in ("pending", "in_progress", "done", "cancelled"):
        if status == "cancelled" and not can_manage_tasks(user):
            return RedirectResponse("/tasks", status_code=303)
        row.status = status
        row.updated_by = user.username
        row.updated_at = datetime.now(timezone.utc)
        db.commit()
    return RedirectResponse("/tasks", status_code=303)

@router.post("/tasks/personal/{tid}/delete")
async def tasks_personal_delete(tid: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not can_manage_tasks(user):
        return RedirectResponse("/tasks", status_code=303)
    row = db.query(PersonalTask).filter(PersonalTask.id == tid).first()
    if row:
        db.delete(row)
        db.commit()
    return RedirectResponse("/tasks", status_code=303)


# ── Me / Notifications / Backup / Archive helpers ────────
@router.get("/me", response_class=HTMLResponse)
async def me_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    my_tasks = db.query(PersonalTask).filter(PersonalTask.assigned_to == user.username).order_by(PersonalTask.id.desc()).limit(20).all()
    my_leaves = db.query(LeaveRequest).filter(LeaveRequest.username == user.username).order_by(LeaveRequest.id.desc()).limit(10).all()
    my_comms = db.query(Commendation).filter(Commendation.target_username == user.username).order_by(Commendation.id.desc()).limit(10).all()
    unread = db.query(SiteNotification).filter(SiteNotification.to_username == user.username, SiteNotification.is_read == False).count()
    return templates.TemplateResponse("me.html", {
        "request": request, "user": user, "my_tasks": my_tasks, "my_leaves": my_leaves,
        "my_comms": my_comms, "unread": unread,
    })

@router.get("/notifications", response_class=HTMLResponse)
async def notifications_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    items = db.query(SiteNotification).filter(SiteNotification.to_username == user.username).order_by(SiteNotification.created_at.desc()).limit(50).all()
    return templates.TemplateResponse("notifications.html", {"request": request, "user": user, "items": items})

@router.post("/notifications/read-all")
async def notifications_read_all(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    for n in db.query(SiteNotification).filter(SiteNotification.to_username == user.username, SiteNotification.is_read == False).all():
        n.is_read = True
    db.commit()
    return RedirectResponse("/notifications", status_code=303)

@router.post("/notifications/{nid}/read")
async def notifications_read_one(nid: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    n = db.query(SiteNotification).filter(SiteNotification.id == nid, SiteNotification.to_username == user.username).first()
    if n:
        n.is_read = True
        db.commit()
        if n.link:
            return RedirectResponse(n.link, status_code=303)
    return RedirectResponse("/notifications", status_code=303)

@router.get("/admin/backup")
async def admin_backup(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not (user.is_admin or is_owner_identity(user.username)):
        return RedirectResponse("/", status_code=303)
    import json
    from fastapi.responses import Response
    payload = {
        "users": [{"username": u.username, "rank": u.rank, "clearance": u.clearance, "display_name": u.display_name} for u in db.query(User).all()],
        "applications_count": db.query(Application).count(),
        "tasks_div": db.query(DivisionTask).count(),
        "tasks_personal": db.query(PersonalTask).count(),
        "exported_at": datetime.now(timezone.utc).isoformat(),
    }
    log_action(db, "backup_export", "json summary", user.username)
    return Response(content=json.dumps(payload, ensure_ascii=False, indent=2), media_type="application/json",
                    headers={"Content-Disposition": "attachment; filename=cia-backup-summary.json"})


@router.get("/api/notif-count")
async def api_notif_count(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return {"count": 0}
    c = db.query(SiteNotification).filter(SiteNotification.to_username == user.username, SiteNotification.is_read == False).count()
    return {"count": c}


# ── Radio (channels 1-120, proximity) + MDT + extras ─────




@router.get("/radio-live", response_class=HTMLResponse)
async def radio_live_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    locks = db.query(RadioChannelLock).order_by(RadioChannelLock.channel).all()
    return templates.TemplateResponse("radio_live.html", {
        "request": request, "user": user, "locks": locks, "radio_max": RADIO_MAX,
        "is_leader": is_owner_identity(user.username) or user.is_admin,
    })

@router.post("/radio-live/tune")
async def radio_tune(request: Request, channel: int = Form(1), radio_on: str = Form("off"), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    ch = max(1, min(RADIO_MAX, int(channel)))
    if not radio_allowed(user, ch, db):
        return templates.TemplateResponse("radio_live.html", {
            "request": request, "user": user, "locks": db.query(RadioChannelLock).all(),
            "radio_max": RADIO_MAX, "error": "هذه الموجة مقيدة — غير مسموح",
            "is_leader": is_owner_identity(user.username) or user.is_admin,
        })
    user.radio_channel = ch
    user.radio_on = radio_on == "on"
    db.commit()
    return RedirectResponse("/radio-live", status_code=303)

@router.post("/radio-live/lock")
async def radio_lock(request: Request, channel: int = Form(...), label: str = Form(""), allowed_ranks: str = Form(""), locked: str = Form("on"), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not (is_owner_identity(user.username) or user.is_admin):
        return RedirectResponse("/radio-live", status_code=303)
    ch = max(1, min(RADIO_MAX, int(channel)))
    row = db.query(RadioChannelLock).filter(RadioChannelLock.channel == ch).first()
    if not row:
        row = RadioChannelLock(channel=ch, created_by=user.username)
        db.add(row)
    row.label = label[:60]
    row.allowed_ranks = allowed_ranks[:200]
    row.locked = locked == "on"
    db.commit()
    return RedirectResponse("/radio-live", status_code=303)

@router.get("/api/radio/peers")
async def api_radio_peers(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not user.radio_on:
        return {"peers": [], "channel": None}
    ch = user.radio_channel or 1
    me_pos = _player_pos_by_name(user.username) or _player_pos_by_name(user.roblox_id or "") or _player_pos_by_name(user.display_name or "")
    peers = []
    for u in db.query(User).filter(User.radio_on == True, User.radio_channel == ch, User.is_active == True).all():
        if u.id == user.id:
            continue
        pos = _player_pos_by_name(u.username) or _player_pos_by_name(u.display_name or "")
        d = _dist(me_pos, pos)
        if me_pos is None or pos is None:
            # no game coords — show with weak signal flag
            peers.append({"username": u.username, "callsign": u.codename or u.callsign or u.display_name, "signal": "unknown", "dist": None})
        elif d is not None and d <= RADIO_RANGE:
            strength = max(0, min(100, int(100 * (1 - d / RADIO_RANGE))))
            peers.append({"username": u.username, "callsign": u.codename or u.callsign or u.display_name, "signal": strength, "dist": round(d, 1)})
        # else out of range — hidden
    return {"peers": peers, "channel": ch, "my_pos": me_pos is not None, "range": RADIO_RANGE}

@router.post("/api/radio/send")
async def api_radio_send(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not user.radio_on:
        return JSONResponse({"ok": False, "error": "radio off"}, status_code=400)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"ok": False}, status_code=400)
    msg = (body.get("message") or "").strip()[:300]
    if not msg:
        return JSONResponse({"ok": False}, status_code=400)
    ch = user.radio_channel or 1
    if not radio_allowed(user, ch, db):
        return JSONResponse({"ok": False, "error": "locked"}, status_code=403)
    db.add(RadioMessage(channel=ch, author=user.username, callsign=user.codename or user.callsign or user.display_name, body=msg))
    db.commit()
    payload = {"type": "radio", "channel": ch, "author": user.username, "callsign": user.codename or user.display_name, "body": msg}
    # broadcast only to same channel radios in range
    me_pos = _player_pos_by_name(user.username) or _player_pos_by_name(user.display_name or "")
    dead = set()
    for ws in list(state.radio_ws):
        try:
            await ws.send_json(payload)
        except Exception:
            dead.add(ws)
    for ws in dead:
        state.radio_ws.discard(ws)
    return {"ok": True}

@router.websocket("/ws/radio")
async def ws_radio(ws: WebSocket):
    if not _ws_origin_ok(ws) or not _ws_user(ws):
        await ws.close(code=4401)
        return
    await ws.accept()
    state.radio_ws.add(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        state.radio_ws.discard(ws)

@router.get("/mdt", response_class=HTMLResponse)
async def mdt_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    incidents = db.query(Incident).filter(Incident.status.in_(["open", "responding"])).order_by(Incident.id.desc()).limit(15).all()
    watch = db.query(Watchlist).order_by(Watchlist.id.desc()).limit(15).all()
    my_tasks = db.query(PersonalTask).filter(PersonalTask.assigned_to == user.username, PersonalTask.status.in_(["pending", "in_progress"])).limit(10).all()
    on_duty = db.query(User).filter(User.duty_status == "on", User.is_active == True).all()
    return templates.TemplateResponse("mdt.html", {
        "request": request, "user": user, "incidents": incidents, "watch": watch,
        "my_tasks": my_tasks, "on_duty": on_duty, "live": state.latest_data,
    })

@router.get("/duty-board", response_class=HTMLResponse)
async def duty_board(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    on_duty = db.query(User).filter(User.duty_status == "on", User.is_active == True).all()
    overdue = db.query(DivisionTask).filter(DivisionTask.status.in_(["pending", "in_progress"])).all()
    # mark overdue in template by date string compare loosely
    return templates.TemplateResponse("duty_board.html", {
        "request": request, "user": user, "on_duty": on_duty, "tasks": overdue,
    })

@router.post("/tasks/template/add")
async def task_template_add(request: Request, division: str = Form(""), title: str = Form(...), description: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not (is_owner_identity(user.username) or user.is_admin):
        return RedirectResponse("/tasks", status_code=303)
    db.add(TaskTemplate(division=division[:20], title=title[:150], description=description[:1000], created_by=user.username))
    db.commit()
    return RedirectResponse("/tasks", status_code=303)

@router.post("/tasks/template/{tid}/apply")
async def task_template_apply(tid: int, request: Request, task_date: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not (is_owner_identity(user.username) or user.is_admin):
        return RedirectResponse("/tasks", status_code=303)
    tpl = db.query(TaskTemplate).filter(TaskTemplate.id == tid).first()
    if tpl and tpl.division in ("DI", "HR", "FOD", "SOG"):
        db.add(DivisionTask(division=tpl.division, title=tpl.title, description=tpl.description, task_date=task_date[:20], created_by=user.username, updated_by=user.username))
        db.commit()
    return RedirectResponse("/tasks", status_code=303)


# ── Division boards, verification, points, completions ───


@router.get("/boards", response_class=HTMLResponse)
async def boards_home(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse("boards.html", {
        "request": request, "user": user, "verified": is_fully_verified(user),
        "divisions": ["DI", "HR", "FOD", "SOG"],
    })

@router.get("/boards/{div}", response_class=HTMLResponse)
async def board_div(div: str, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    div = div.upper()
    if div not in ("DI", "HR", "FOD", "SOG"):
        return RedirectResponse("/boards", status_code=303)
    templates_list = db.query(TaskTemplate).filter(TaskTemplate.division == div).order_by(TaskTemplate.id).all()
    active = db.query(DivisionTask).filter(DivisionTask.division == div, DivisionTask.status.in_(["pending", "in_progress"])).order_by(DivisionTask.id.desc()).limit(40).all()
    return templates.TemplateResponse("board_div.html", {
        "request": request, "user": user, "div": div,
        "templates_list": templates_list, "active": active,
        "verified": is_fully_verified(user),
        "can_deploy": is_owner_identity(user.username) or user.is_admin or can_manage_division(user.rank, user.username, div, user.is_admin),
    })

@router.post("/boards/{div}/deploy/{tid}")
async def board_deploy(div: str, tid: int, request: Request, task_date: str = Form(""), points: int = Form(10), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    div = div.upper()
    if not user or not (is_owner_identity(user.username) or user.is_admin or can_manage_division(user.rank, user.username, div, user.is_admin)):
        return RedirectResponse(f"/boards/{div}", status_code=303)
    tpl = db.query(TaskTemplate).filter(TaskTemplate.id == tid).first()
    if tpl:
        db.add(DivisionTask(
            division=div, title=tpl.title, description=(tpl.description or "") + f"\n[نقاط مقترحة: {int(points)}]",
            task_date=task_date[:20], priority="normal", created_by=user.username, updated_by=user.username,
        ))
        db.commit()
        await notify_bot({"type": "custom", "message": f"📋 مهمة {div} نزلت: {tpl.title}"})
    return RedirectResponse(f"/boards/{div}", status_code=303)

@router.post("/tasks/complete")
async def task_complete(
    request: Request,
    task_type: str = Form("division"),
    task_id: int = Form(...),
    evidence_text: str = Form(""),
    witnesses: str = Form(""),
    db: Session = Depends(get_db),
):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not is_fully_verified(user):
        return RedirectResponse("/boards", status_code=303)
    if not evidence_text.strip() and not witnesses.strip():
        # require one of them; file optional below
        pass
    file_path = ""
    form = await request.form()
    up = form.get("file")
    if up is not None and hasattr(up, "filename") and up.filename:
        import secrets as _s
        from pathlib import Path as _P
        ext = _P(up.filename).suffix.lower()
        if ext not in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".pdf", ".txt", ".mp4", ".webm"}:
            return RedirectResponse("/tasks", status_code=303)
        name = f"u{user.id}_{_s.token_hex(6)}{ext}"
        dest = _P("data/uploads") / name
        data = await up.read()
        if len(data) <= 5_000_000:  # 5MB
            dest.write_bytes(data)
            file_path = str(dest)
    if not evidence_text.strip() and not witnesses.strip() and not file_path:
        return RedirectResponse("/tasks", status_code=303)
    if task_type not in ("division", "personal"):
        return RedirectResponse("/tasks", status_code=303)
    db.add(TaskCompletion(
        task_type=task_type[:20], task_id=int(task_id), submitter=user.username,
        evidence_text=evidence_text[:2000], witnesses=witnesses[:500], file_path=file_path,
    ))
    db.commit()
    await notify_bot({"type": "custom", "message": f"📎 إثبات مهمة من {user.username} بانتظار مراجعة القيادة"})
    return RedirectResponse("/tasks", status_code=303)

@router.get("/reviews", response_class=HTMLResponse)
async def reviews_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not (is_owner_identity(user.username) or user.is_admin or user.rank in ("HR", "Director", "SAC")):
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    items = db.query(TaskCompletion).order_by(TaskCompletion.created_at.desc()).limit(50).all()
    return templates.TemplateResponse("reviews.html", {"request": request, "user": user, "items": items})

@router.post("/reviews/{cid}/decide")
async def reviews_decide(cid: int, request: Request, status: str = Form(...), points: int = Form(10), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not (is_owner_identity(user.username) or user.is_admin or user.rank in ("HR", "Director")):
        return RedirectResponse("/reviews", status_code=303)
    row = db.query(TaskCompletion).filter(TaskCompletion.id == cid).first()
    if not row or row.status != "pending":
        return RedirectResponse("/reviews", status_code=303)
    if status not in ("approved", "rejected"):
        return RedirectResponse("/reviews", status_code=303)
    row.status = status
    row.reviewed_by = user.username
    pts = max(0, min(100, int(points)))
    if status == "approved":
        row.points_awarded = pts
        agent = db.query(User).filter(User.username == row.submitter).first()
        if agent:
            agent.points = (agent.points or 0) + pts
            # auto rank suggestion by points
            for need, rank_name in sorted(POINTS_PROMOTE, reverse=True):
                if agent.points >= need and rank_level(agent.rank) < rank_level(rank_name):
                    # only auto-promote if below target and not owner
                    if not is_owner_identity(agent.username) and agent.rank not in ("Owner", "Director"):
                        agent.rank = rank_name
                    break
            await push_site_notif(db, agent.username, "تمت الموافقة على مهمة", f"+{pts} نقطة · المجموع {agent.points}", "/me")
            await notify_bot({"type": "custom", "discord": agent.username, "message": f"✅ مهمة مقبولة +{pts} نقطة (الإجمالي {agent.points})"})
        if row.task_type == "division":
            t = db.query(DivisionTask).filter(DivisionTask.id == row.task_id).first()
            if t:
                t.status = "done"
    db.commit()
    return RedirectResponse("/reviews", status_code=303)

# ── API / WS ─────────────────────────────────────────────
@router.get("/api/status")
@limiter.limit("30/minute")
async def api_status(request: Request):
    return {"ok": True, "player_count": state.latest_data["player_count"], "last_update": state.latest_data["last_update"]}

@router.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    u = _ws_user(ws)
    if not _ws_origin_ok(ws) or not u or not (
        u.can_view_map or u.is_admin or is_owner_identity(u.username)
    ):
        await ws.close(code=4401)
        return
    await ws.accept()
    state.map_ws.add(ws)
    await ws.send_json({"type": "update", "data": state.latest_data})
    try:
        while True:
            data = await ws.receive_text()
            if data == "ping":
                await ws.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        state.map_ws.discard(ws)


# ── Full ER:LC API surfaces ──────────────────────────────
@router.get("/live", response_class=HTMLResponse)
async def live_intel(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not (user.can_view_map or user.is_admin or is_owner_identity(user.username)):
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    return templates.TemplateResponse("live.html", {
        "request": request, "user": user, "live": state.latest_data,
        "can_cmd": user.is_admin or is_owner_identity(user.username),
    })

@router.get("/api/live/full")
async def api_live_full(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return JSONResponse({"error": "auth"}, status_code=401)
    if not (user.can_view_map or user.is_admin or is_owner_identity(user.username)):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    return state.latest_data

@router.post("/api/live/command")
async def api_live_command(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not (user.is_admin or is_owner_identity(user.username)):
        return JSONResponse({"ok": False, "error": "forbidden"}, status_code=403)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"ok": False, "error": "json"}, status_code=400)
    cmd = (body.get("command") or "").strip()
    if not cmd:
        return JSONResponse({"ok": False, "error": "empty"}, status_code=400)
    from services.erlc_poll import client
    result = await client.run_command(cmd)
    log_action(db, "erlc_command", cmd[:120], user.username)
    return result


"""Login, logout, Discord OAuth."""
from __future__ import annotations

import logging
import secrets
import time
from datetime import datetime, timezone
from urllib.parse import urlencode

import httpx
from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from config import settings, ROLE_MAP, ROLE_PRIORITY, OWNER_DISCORD_IDS
from database import get_db
from deps import (
    elevate_if_owner,
    get_current_user,
    hash_password,
    log_action,
    start_session,
    verify_password,
)
from models import User
from limiter import limiter
import totp
from security import (
    check_user_locked,
    get_client_ip,
    handle_failed_login,
    is_ip_blocked,
    record_security_event,
    reset_failed_on_success,
)
from ranks import is_supreme, is_owner_identity

logger = logging.getLogger("cia.auth")
router = APIRouter(tags=["auth"])
templates = Jinja2Templates(directory="templates")

DISCORD_API = "https://discord.com/api/v10"
DISCORD_AUTH = "https://discord.com/api/oauth2/authorize"
DISCORD_TOKEN = "https://discord.com/api/oauth2/token"


def apply_role_permissions(user: User, role_ids: list) -> bool:
    matched = None
    for rid in ROLE_PRIORITY:
        if rid in role_ids and rid in ROLE_MAP:
            matched = ROLE_MAP[rid]
            break
    if not matched:
        for rid in role_ids:
            if rid in ROLE_MAP:
                matched = ROLE_MAP[rid]
                break
    if not matched:
        return False
    user.rank = matched.get("rank", user.rank)
    user.clearance = matched.get("clearance", user.clearance)
    user.is_admin = matched.get("is_admin", False)
    for key in (
        "can_view_map",
        "can_view_personnel",
        "can_manage_personnel",
        "can_view_applications",
        "can_manage_applications",
        "can_issue_id",
        "can_view_logs",
        "can_manage_blacklist",
        "can_view_vehicles",
    ):
        setattr(user, key, matched.get(key, False))
    return True


@router.get("/login", response_class=HTMLResponse)
async def login_page(request: Request, db: Session = Depends(get_db)):
    ip = get_client_ip(request)
    blocked, ban_msg = is_ip_blocked(db, ip)
    if blocked:
        return templates.TemplateResponse("blocked.html", {"request": request, "message": ban_msg})
    error = request.query_params.get("error")
    messages = {
        "discord_denied": "تم رفض الدخول عبر Discord",
        "invalid_state": "طلب غير صالح. حاول مرة أخرى.",
        "token_failed": "فشل التوكن من Discord",
    }
    return templates.TemplateResponse(
        "login.html",
        {
            "request": request,
            "error": messages.get(error, "حدث خطأ" if error else None),
            "discord_enabled": bool(settings.discord_client_id and settings.discord_redirect_uri),
        },
    )


@router.post("/login")
async def login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    ip = get_client_ip(request)
    blocked, ban_msg = is_ip_blocked(db, ip)
    if blocked:
        return templates.TemplateResponse("blocked.html", {"request": request, "message": ban_msg})

    user = db.query(User).filter(User.username == username).first()
    if user and is_supreme(user.username):
        user.is_locked = False
        user.is_active = True

    locked, lock_msg = check_user_locked(user)
    if locked and not (user and is_supreme(user.username)):
        record_security_event(db, "locked_attempt", ip, username, "Tried locked account", "high")
        return templates.TemplateResponse("blocked.html", {"request": request, "message": lock_msg})

    if not user or not verify_password(password, user.password_hash or ""):
        result = handle_failed_login(db, ip, username)
        if result["ip_banned"] or result["account_locked"]:
            return templates.TemplateResponse(
                "blocked.html", {"request": request, "message": result["message"]}
            )
        return templates.TemplateResponse(
            "login.html",
            {
                "request": request,
                "error": result["message"],
                "discord_enabled": bool(settings.discord_client_id),
            },
        )

    elevate_if_owner(user)
    reset_failed_on_success(db, user, ip)
    if user.totp_enabled and user.totp_secret:      # password OK → second factor required
        request.session.clear()
        request.session["pending_2fa"] = user.id
        request.session["p2ts"] = int(time.time())
        db.commit()
        return RedirectResponse("/login/2fa", status_code=303)
    start_session(request, user)
    user.last_login = datetime.now(timezone.utc)
    db.commit()
    log_action(db, "login", f"from {ip}", user.username)
    return RedirectResponse("/", status_code=303)


@router.get("/login/2fa", response_class=HTMLResponse)
async def login_2fa_page(request: Request):
    if not request.session.get("pending_2fa"):
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse("login_2fa.html", {"request": request, "error": None})


@router.post("/login/2fa")
@limiter.limit("10/minute")
async def login_2fa(request: Request, code: str = Form(...), db: Session = Depends(get_db)):
    ip = get_client_ip(request)
    blocked, ban_msg = is_ip_blocked(db, ip)
    if blocked:
        return templates.TemplateResponse("blocked.html", {"request": request, "message": ban_msg})
    uid = request.session.get("pending_2fa")
    if not uid or int(time.time()) - request.session.get("p2ts", 0) > 300:   # 5-minute window
        request.session.clear()
        return RedirectResponse("/login", status_code=303)
    user = db.query(User).filter(User.id == uid, User.is_active == True).first()
    step = totp.verify(user.totp_secret, code, user.totp_last_step or 0) if user else None
    if not user or step is None:
        result = handle_failed_login(db, ip, user.username if user else "")
        if result["ip_banned"] or result["account_locked"]:
            return templates.TemplateResponse("blocked.html", {"request": request, "message": result["message"]})
        return templates.TemplateResponse("login_2fa.html", {"request": request, "error": "الرمز غير صحيح"})
    user.totp_last_step = step                      # one-time use
    user.last_login = datetime.now(timezone.utc)
    db.commit()
    start_session(request, user)
    log_action(db, "login_2fa", f"from {ip}", user.username)
    return RedirectResponse("/", status_code=303)


@router.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


@router.get("/auth/discord")
async def discord_login(request: Request):
    if not settings.discord_client_id or not settings.discord_redirect_uri:
        return HTMLResponse("Discord OAuth not configured", status_code=500)
    state = secrets.token_urlsafe(24)
    request.session["oauth_state"] = state
    params = {
        "client_id": settings.discord_client_id,
        "redirect_uri": settings.discord_redirect_uri,
        "response_type": "code",
        "scope": "identify guilds guilds.members.read",
        "state": state,
        "prompt": "none",
    }
    return RedirectResponse(f"{DISCORD_AUTH}?{urlencode(params)}")


@router.get("/auth/discord/callback")
async def discord_callback(
    request: Request,
    code: str = None,
    state: str = None,
    error: str = None,
    db: Session = Depends(get_db),
):
    ip = get_client_ip(request)
    blocked, ban_msg = is_ip_blocked(db, ip)
    if blocked:
        return templates.TemplateResponse("blocked.html", {"request": request, "message": ban_msg})
    if error:
        return RedirectResponse("/login?error=discord_denied")
    if not code or not state or state != request.session.get("oauth_state"):
        return RedirectResponse("/login?error=invalid_state")
    request.session.pop("oauth_state", None)

    async with httpx.AsyncClient(timeout=10.0) as http:
        token_resp = await http.post(
            DISCORD_TOKEN,
            data={
                "client_id": settings.discord_client_id,
                "client_secret": settings.discord_client_secret,
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": settings.discord_redirect_uri,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        if token_resp.status_code != 200:
            return RedirectResponse("/login?error=token_failed")
        access_token = token_resp.json().get("access_token")
        if not access_token:
            return RedirectResponse("/login?error=token_failed")

        user_resp = await http.get(
            f"{DISCORD_API}/users/@me",
            headers={"Authorization": f"Bearer {access_token}"},
        )
        if user_resp.status_code != 200:
            return RedirectResponse("/login?error=token_failed")
        duser = user_resp.json()
        discord_id = str(duser["id"])
        username = duser.get("username") or "Unknown"
        global_name = duser.get("global_name") or username
        avatar = duser.get("avatar") or ""

        role_ids = []
        roles_known = False
        if settings.discord_guild_id:
            headers = {}
            if settings.discord_bot_token:
                headers["Authorization"] = f"Bot {settings.discord_bot_token}"
                member_url = f"{DISCORD_API}/guilds/{settings.discord_guild_id}/members/{discord_id}"
            else:
                headers["Authorization"] = f"Bearer {access_token}"
                member_url = f"{DISCORD_API}/users/@me/guilds/{settings.discord_guild_id}/member"
            member_resp = await http.get(member_url, headers=headers)
            if member_resp.status_code == 200:
                role_ids = [str(r) for r in member_resp.json().get("roles", [])]
                roles_known = True
            elif member_resp.status_code == 404:  # not in the guild at all
                roles_known = True

    # Match ONLY by immutable Discord ID. Matching by username let anyone who held a
    # Discord handle equal to a portal account take that account over.
    user = db.query(User).filter(User.discord_id == discord_id).first()
    is_owner_discord = discord_id in OWNER_DISCORD_IDS
    if not user and is_owner_discord:
        # Link the whitelisted owner's Discord to the default admin account (first time only)
        admin = db.query(User).filter(User.username == settings.admin_username).first()
        if admin and not admin.discord_id:
            user = admin
    if not user:
        safe_name = username[:50]
        taken = db.query(User).filter(User.username == safe_name).first()
        if taken or (is_owner_identity(safe_name) and not is_owner_discord):
            safe_name = f"{safe_name}_{discord_id[-4:]}"
        user = User(
            username=safe_name,
            discord_id=discord_id,
            display_name=global_name[:100],
            discord_avatar=avatar,
            rank="Recruit",
            clearance="Restricted",
        )
        db.add(user)
    else:
        user.discord_id = discord_id
        user.display_name = global_name[:100]
        user.discord_avatar = avatar

    matched = apply_role_permissions(user, role_ids)
    if not matched and not is_owner_discord:
        # Lost the Discord role (or never had one) → drop back to minimum access.
        # Only when Discord answered, so an API hiccup doesn't strip real staff.
        if roles_known or not user.id:
            user.rank = "Recruit"
            user.clearance = "Restricted"
            user.is_admin = False
            for key in ("can_view_map", "can_view_personnel", "can_manage_personnel",
                        "can_manage_applications", "can_issue_id", "can_view_logs",
                        "can_manage_blacklist", "can_view_vehicles"):
                setattr(user, key, False)
        user.can_view_applications = True

    locked, lock_msg = check_user_locked(user)
    if locked and not user.is_admin and not is_supreme(user.username):
        return templates.TemplateResponse("blocked.html", {"request": request, "message": lock_msg})

    elevate_if_owner(user, via_discord=True)
    if user.verified_roblox and user.roblox_id:
        import roblox
        user.roblox_avatar = (await roblox.get_headshot(user.roblox_id)) or user.roblox_avatar
    user.verified_discord = True
    user.last_login = datetime.now(timezone.utc)
    if not user.is_locked:
        user.is_active = True
    db.commit()

    start_session(request, user)
    log_action(db, "discord_login", f"{user.display_name} roles={role_ids}", user.username)
    return RedirectResponse("/", status_code=303)

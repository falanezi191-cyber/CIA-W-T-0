"""Units (الفرق): every member belongs to a unit and gets a number inside it, e.g. FOD-07."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

import discord_api
from config import UNITS
from database import get_db
from deps import get_current_user, log_action, push_site_notif
from models import User
from ranks import can_manage_division, is_owner_identity, is_supreme
from routers.linking import nick_for

router = APIRouter(tags=["units"])
templates = Jinja2Templates(directory="templates")
MAX_NUM = 999


def _can_manage(user: User, unit: str) -> bool:
    return bool(
        user.is_admin or user.can_manage_personnel or is_owner_identity(user.username)
        or is_supreme(user.username) or can_manage_division(user.rank, user.username, unit, user.is_admin)
    )


def _next_free(db: Session, unit: str) -> int:
    used = {n for (n,) in db.query(User.unit_number).filter(User.unit == unit, User.unit_number > 0).all()}
    n = 1
    while n in used:
        n += 1
    return n


@router.get("/units", response_class=HTMLResponse)
async def units_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    members = db.query(User).filter(User.is_active == True).order_by(User.unit, User.unit_number, User.id).all()
    by_unit = {u: [m for m in members if m.unit == u] for u in UNITS}
    unassigned = [m for m in members if not m.unit or m.unit not in UNITS]
    can_edit = any(_can_manage(user, u) for u in UNITS)
    return templates.TemplateResponse("units.html", {
        "request": request, "user": user, "units": UNITS, "by_unit": by_unit,
        "unassigned": unassigned, "can_edit": can_edit, "msg": request.query_params.get("m"),
        "manageable": [u for u in UNITS if _can_manage(user, u)],
    })


@router.post("/units/assign")
async def units_assign(request: Request, user_id: int = Form(...), unit: str = Form(...),
                       number: str = Form(""), db: Session = Depends(get_db)):
    actor = get_current_user(request, db)
    if not actor:
        return RedirectResponse("/login", status_code=303)
    unit = unit.strip().upper()
    target = db.query(User).filter(User.id == user_id).first()
    if not target or unit not in UNITS or not _can_manage(actor, unit):
        return RedirectResponse("/units?m=denied", status_code=303)
    if is_owner_identity(target.username) and not (is_owner_identity(actor.username) or is_supreme(actor.username)):
        return RedirectResponse("/units?m=denied", status_code=303)
    # moving someone OUT of a unit also requires managing that unit
    if target.unit and target.unit != unit and target.unit in UNITS and not _can_manage(actor, target.unit):
        return RedirectResponse("/units?m=denied", status_code=303)
    if number.strip():
        if not number.strip().isdigit() or not (1 <= int(number) <= MAX_NUM):
            return RedirectResponse("/units?m=badnum", status_code=303)
        num = int(number)
        clash = db.query(User).filter(User.unit == unit, User.unit_number == num, User.id != target.id).first()
        if clash:
            return RedirectResponse(f"/units?m=taken:{unit}-{num:02d}", status_code=303)
    else:
        num = target.unit_number if (target.unit == unit and target.unit_number) else _next_free(db, unit)
    target.unit, target.unit_number = unit, num
    target.callsign = target.unit_tag                  # radio / MDT use callsign automatically
    db.commit()
    log_action(db, "unit_assign", f"{target.username} -> {target.unit_tag}", actor.username)
    await push_site_notif(db, target.username, "تم تعيينك في فرقة", f"رقمك: {target.unit_tag}", "/me")
    if target.discord_id and target.verified_roblox:
        await discord_api.sync_member(target.discord_id, nick=nick_for(target), reason=f"Unit {target.unit_tag}")
    return RedirectResponse(f"/units?m=ok:{target.unit_tag}", status_code=303)


@router.post("/units/clear")
async def units_clear(request: Request, user_id: int = Form(...), db: Session = Depends(get_db)):
    actor = get_current_user(request, db)
    if not actor:
        return RedirectResponse("/login", status_code=303)
    target = db.query(User).filter(User.id == user_id).first()
    if not target or not target.unit or not _can_manage(actor, target.unit):
        return RedirectResponse("/units?m=denied", status_code=303)
    old = target.unit_tag
    target.unit, target.unit_number, target.callsign = "", 0, ""
    db.commit()
    log_action(db, "unit_clear", f"{target.username} left {old}", actor.username)
    if target.discord_id and target.verified_roblox:
        await discord_api.sync_member(target.discord_id, nick=nick_for(target), reason="Unit cleared")
    return RedirectResponse("/units?m=ok", status_code=303)

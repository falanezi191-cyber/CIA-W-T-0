"""Roblox account linking (proof of ownership via a code in the Roblox profile) + new-member application page."""
from __future__ import annotations

import secrets
import time
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

import discord_api
import roblox
from config import settings
from database import get_db
from deps import get_current_user, log_action
from limiter import limiter
from models import Application, User
from notify import notify_bot

router = APIRouter(tags=["linking"])
templates = Jinja2Templates(directory="templates")
CODE_TTL = 30 * 60


def nick_for(user: User) -> str:
    """[Rank] UNIT-07 | RobloxName — always ≤ 32 chars (Discord limit); the name is trimmed first."""
    name = user.roblox_username or user.display_name or user.username
    prefix = f"[{user.rank}] " + (f"{user.unit_tag} | " if user.unit_tag else "")
    if len(prefix) > 24:
        prefix = (f"{user.unit_tag} | " if user.unit_tag else f"[{user.rank}] ")
    return (prefix + name)[:32]


@router.get("/link/roblox", response_class=HTMLResponse)
async def link_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    pend = request.session.get("rbx_pending")
    if pend and time.time() - pend.get("ts", 0) > CODE_TTL:
        request.session.pop("rbx_pending", None)
        pend = None
    return templates.TemplateResponse("link_roblox.html", {
        "request": request, "user": user, "pend": pend, "error": request.query_params.get("e"),
    })


@router.post("/link/roblox/start")
@limiter.limit("10/minute")
async def link_start(request: Request, roblox_username: str = Form(...), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    info = await roblox.lookup_user(roblox_username.strip())
    if not info:
        return RedirectResponse("/link/roblox?e=notfound", status_code=303)
    rid = str(info["id"])
    other = db.query(User).filter(User.roblox_id == rid, User.id != user.id, User.verified_roblox == True).first()
    if other:
        log_action(db, "roblox_link_conflict", f"{rid} already linked to {other.username}", user.username)
        return RedirectResponse("/link/roblox?e=taken", status_code=303)
    request.session["rbx_pending"] = {
        "id": rid, "name": info["name"], "code": "CIA-" + secrets.token_hex(4).upper(), "ts": time.time(),
    }
    return RedirectResponse("/link/roblox", status_code=303)


@router.post("/link/roblox/check")
@limiter.limit("12/minute")
async def link_check(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    pend = request.session.get("rbx_pending")
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not pend or time.time() - pend.get("ts", 0) > CODE_TTL:
        request.session.pop("rbx_pending", None)
        return RedirectResponse("/link/roblox?e=expired", status_code=303)
    desc = await roblox.get_description(pend["id"])
    if desc is None:
        return RedirectResponse("/link/roblox?e=api", status_code=303)
    if pend["code"] not in desc:
        return RedirectResponse("/link/roblox?e=nocode", status_code=303)
    user.roblox_id, user.roblox_username, user.verified_roblox = pend["id"], pend["name"], True
    user.roblox_avatar = await roblox.get_headshot(pend["id"])
    db.commit()
    request.session.pop("rbx_pending", None)
    log_action(db, "roblox_linked", f"{pend['name']} ({pend['id']})", user.username)
    if user.discord_id and discord_api.enabled():
        await discord_api.sync_member(user.discord_id, nick=nick_for(user), reason="Roblox linked")
    return RedirectResponse("/", status_code=303)


@router.post("/link/roblox/reset")
async def link_reset(request: Request):
    request.session.pop("rbx_pending", None)
    return RedirectResponse("/link/roblox", status_code=303)


@router.get("/verify/roblox")
async def old_verify():
    return RedirectResponse("/link/roblox", status_code=303)


# ── New-member application (the only page a Recruit sees) ─────────────
@router.get("/my-application", response_class=HTMLResponse)
async def my_application(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    last = db.query(Application).filter(Application.user_id == user.id).order_by(Application.id.desc()).first()
    return templates.TemplateResponse("my_application.html", {
        "request": request, "user": user, "last": last, "sent": request.query_params.get("sent"),
    })


@router.get("/apply")
async def apply_redirect():
    return RedirectResponse("/my-application", status_code=303)


@router.post("/apply")
@limiter.limit("3/minute")
async def submit_application(
    request: Request,
    full_name: str = Form(...), age: str = Form(""),
    experience: str = Form(""), reason: str = Form(""),
    db: Session = Depends(get_db),
):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    last = db.query(Application).filter(Application.user_id == user.id).order_by(Application.id.desc()).first()
    if last and last.status == "pending":
        return RedirectResponse("/my-application", status_code=303)
    if last and last.status == "rejected" and last.reviewed_at:
        ra = last.reviewed_at if last.reviewed_at.tzinfo else last.reviewed_at.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - ra < timedelta(days=3):        # cool-down after rejection
            return RedirectResponse("/my-application", status_code=303)
    # Identity comes from the VERIFIED links, never from what the user types.
    db.add(Application(
        app_type="join", user_id=user.id, discord_id=user.discord_id or "",
        full_name=full_name[:100], roblox_username=user.roblox_username or "", roblox_id=user.roblox_id or "",
        discord=(user.display_name or user.username)[:80], age=age[:10],
        experience=experience[:2000], reason=reason[:2000],
    ))
    db.commit()
    log_action(db, "new_application", f"from {user.username}", user.username)
    await notify_bot({"type": "custom", "message": f"📋 تقديم جديد من {user.display_name} (Roblox: {user.roblox_username})"})
    return RedirectResponse("/my-application?sent=1", status_code=303)

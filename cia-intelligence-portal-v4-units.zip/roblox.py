"""Roblox public APIs: username lookup, profile description (for ownership proof), avatar headshot."""
from __future__ import annotations

import logging
import re
from typing import Optional

import httpx

log = logging.getLogger("cia.roblox")
NAME_RE = re.compile(r"^[A-Za-z0-9_]{3,20}$")


async def lookup_user(username: str) -> Optional[dict]:
    if not NAME_RE.match(username or ""):
        return None
    try:
        async with httpx.AsyncClient(timeout=10.0) as c:
            r = await c.post("https://users.roblox.com/v1/usernames/users",
                             json={"usernames": [username], "excludeBannedUsers": True})
            data = (r.json().get("data") or []) if r.status_code == 200 else []
            return data[0] if data else None
    except Exception as e:
        log.warning("roblox lookup failed: %s", e)
        return None


async def get_description(roblox_id: str) -> Optional[str]:
    try:
        async with httpx.AsyncClient(timeout=10.0) as c:
            r = await c.get(f"https://users.roblox.com/v1/users/{int(roblox_id)}")
            return (r.json().get("description") or "") if r.status_code == 200 else None
    except Exception as e:
        log.warning("roblox description failed: %s", e)
        return None


async def get_headshot(roblox_id: str) -> str:
    try:
        async with httpx.AsyncClient(timeout=10.0) as c:
            r = await c.get("https://thumbnails.roblox.com/v1/users/avatar-headshot",
                            params={"userIds": int(roblox_id), "size": "420x420", "format": "Png", "isCircular": "false"})
            d = (r.json().get("data") or []) if r.status_code == 200 else []
            if d and d[0].get("state") == "Completed":
                return d[0].get("imageUrl") or ""
    except Exception as e:
        log.warning("roblox headshot failed: %s", e)
    return ""

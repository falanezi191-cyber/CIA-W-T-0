# نشر على Render

## Build
```
pip install -r requirements.txt
```

## Start
```
uvicorn main:app --host 0.0.0.0 --port $PORT
```

## Root Directory
مجلد المشروع نفسه (حيث يوجد main.py) — ليس مجلد أعلى.

## Environment (إلزامي)
```
ERLC_SERVER_KEY=...
SECRET_KEY=نص_طويل_عشوائي_32+
ADMIN_USERNAME=f_ksa9
ADMIN_PASSWORD=كلمة_قوية
```

## اختياري
```
DISCORD_CLIENT_ID=
DISCORD_CLIENT_SECRET=
DISCORD_GUILD_ID=
DISCORD_REDIRECT_URI=https://YOUR.onrender.com/auth/discord/callback
DISCORD_BOT_TOKEN=
BOT_NOTIFY_URL=
BOT_NOTIFY_SECRET=
```

## بعد أول Deploy
1. افتح الموقع
2. ادخل بـ f_ksa9 / ADMIN_PASSWORD أو Discord
3. في Discord Portal أضف Redirect URI نفسه

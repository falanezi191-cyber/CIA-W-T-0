from __future__ import annotations
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional
import httpx
from config import settings

logger = logging.getLogger("erlc_client")
BASE_URL = "https://api.erlc.gg/v2"

class ERLCClient:
    def __init__(self):
        self.server_key = settings.erlc_server_key
        self._client: Optional[httpx.AsyncClient] = None

    async def start(self):
        self._client = httpx.AsyncClient(
            base_url=BASE_URL,
            headers={"server-key": self.server_key},
            timeout=15.0,
        )

    async def close(self):
        if self._client:
            await self._client.aclose()

    async def fetch_server(self, players=True, vehicles=True, join_logs=True) -> Dict[str, Any]:
        if not self._client:
            raise RuntimeError("Client not started")
        params = {}
        if players: params["Players"] = "true"
        if vehicles: params["Vehicles"] = "true"
        if join_logs: params["JoinLogs"] = "true"
        try:
            resp = await self._client.get("/server", params=params)
            resp.raise_for_status()
            data = resp.json()
            data["_fetched_at"] = datetime.now(timezone.utc).isoformat()
            return data
        except Exception as e:
            logger.error(f"API error: {e}")
            raise

    @staticmethod
    def parse_player(raw: Dict[str, Any]) -> Dict[str, Any]:
        player_str = raw.get("Player", "")
        name, _, pid = player_str.partition(":")
        loc = raw.get("Location") or {}
        return {
            "id": pid or None,
            "username": name or player_str,
            "raw": player_str,
            "team": raw.get("Team"),
            "callsign": raw.get("Callsign"),
            "permission": raw.get("Permission"),
            "wanted_stars": raw.get("WantedStars", 0),
            "location": {
                "x": loc.get("LocationX"),
                "z": loc.get("LocationZ"),
                "postal": loc.get("PostalCode"),
                "street": loc.get("StreetName"),
                "building": loc.get("BuildingNumber"),
            },
            "has_location": loc.get("LocationX") is not None,
        }

    @staticmethod
    def parse_vehicle(raw: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "name": raw.get("Name"),
            "owner": raw.get("Owner"),
            "plate": raw.get("Plate"),
            "texture": raw.get("Texture"),
            "color_hex": raw.get("ColorHex"),
            "color_name": raw.get("ColorName"),
        }

    @staticmethod
    def parse_join_log(raw: Dict[str, Any]) -> Dict[str, Any]:
        player_str = raw.get("Player", "")
        name, _, pid = player_str.partition(":")
        return {
            "join": bool(raw.get("Join")),
            "timestamp": raw.get("Timestamp"),
            "username": name or player_str,
            "id": pid or None,
        }

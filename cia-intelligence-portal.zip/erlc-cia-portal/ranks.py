"""Rank hierarchy — Owners are highest and protected from each other."""
RANK_LEVEL = {
    "Owner": 100,
    "أونر": 100,
    "Director": 90,
    "Deputy Director": 80,
    "SAC": 60,
    "Special Agent": 50,
    "Agent": 40,
    "Recruit": 10,
}

# Hardcoded portal owners (Discord / login usernames) — full control
PORTAL_OWNERS = {
    "f_ksa9",
    "fysl3",
}

def level(rank: str) -> int:
    if not rank:
        return 0
    r = rank.strip()
    if r in RANK_LEVEL:
        return RANK_LEVEL[r]
    low = r.lower()
    for k, v in RANK_LEVEL.items():
        if k.lower() in low or low in k.lower():
            return v
    return 20

def is_owner_identity(username: str = "", discord_name: str = "", display_name: str = "") -> bool:
    names = {(username or "").lower(), (discord_name or "").lower(), (display_name or "").lower()}
    owners = {o.lower() for o in PORTAL_OWNERS}
    return bool(names & owners)

def can_manage_user(actor_rank: str, actor_is_admin: bool, target_rank: str, target_is_admin: bool,
                    actor_username: str = "", target_username: str = "") -> bool:
    """Owners cannot lock/edit each other. Lower cannot touch equal or higher."""
    if is_owner_identity(actor_username) and is_owner_identity(target_username):
        return False  # owners never fight each other via system
    if is_owner_identity(target_username) and not is_owner_identity(actor_username):
        return False  # only an owner can manage... but not other owners
    al = level(actor_rank)
    tl = level(target_rank)
    if al >= 100 and tl >= 100:
        return False
    if tl >= 100 and al < 100:
        return False
    if is_owner_identity(actor_username):
        return True  # owner can manage non-owners
    if al > tl:
        return True
    if actor_is_admin and tl < 90:
        return True
    return False

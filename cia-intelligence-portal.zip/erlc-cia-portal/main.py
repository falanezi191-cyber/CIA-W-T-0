"""
CIA Intelligence Portal — Full Department Website for ER:LC
Discord OAuth + Strong Security
"""
from __future__ import annotations
import asyncio
import logging
import secrets
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any, Dict, Set, Optional
from urllib.parse import urlencode

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.httpsredirect import HTTPSRedirectMiddleware
from passlib.context import CryptContext
from sqlalchemy.orm import Session
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import httpx

from config import settings, ROLE_MAP, ROLE_PRIORITY
from database import init_db, get_db, SessionLocal
from models import User, Application, Blacklist, ActivityLog, SecurityEvent, BlockedIP, Announcement, SecurityEvent, BlockedIP
from erlc_client import ERLCClient
from ai_assistant import chat as ai_chat
from ranks import can_manage_user, level as rank_level, is_owner_identity, PORTAL_OWNERS
from notify import notify_bot
from security import (
    get_client_ip, is_ip_blocked, handle_failed_login,
    reset_failed_on_success, check_user_locked, record_security_event
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)-7s | %(message)s")
logger = logging.getLogger("cia")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
limiter = Limiter(key_func=get_remote_address)
client = ERLCClient()
connected_ws: Set[WebSocket] = set()
latest_data: Dict[str, Any] = {
    "players": [], "vehicles": [], "join_logs": [],
    "server": {}, "last_update": None, "player_count": 0, "error": None
}
poll_task = None

DISCORD_API = "https://discord.com/api/v10"
DISCORD_AUTH = "https://discord.com/api/oauth2/authorize"
DISCORD_TOKEN = "https://discord.com/api/oauth2/token"

# ── Helpers ──────────────────────────────────────────────
def hash_password(p: str) -> str:
    return pwd_context.hash(p)

def verify_password(plain: str, hashed: str) -> bool:
    if not hashed:
        return False
    return pwd_context.verify(plain, hashed)

def get_current_user(request: Request, db: Session) -> Optional[User]:
    uid = request.session.get("user_id")
    if not uid:
        return None
    return db.query(User).filter(User.id == uid, User.is_active == True).first()


def elevate_if_owner(user: User):
    """Force Owner rank + full permissions for portal owners."""
    if not is_owner_identity(user.username, "", user.display_name or ""):
        # also check discord-style username without discriminator
        if not is_owner_identity(user.username):
            return
    user.rank = "Owner"
    user.clearance = "Top Secret"
    user.is_admin = True
    user.is_active = True
    user.is_locked = False
    user.can_view_map = True
    user.can_view_personnel = True
    user.can_manage_personnel = True
    user.can_view_applications = True
    user.can_manage_applications = True
    user.can_issue_id = True
    user.can_view_logs = True
    user.can_manage_blacklist = True
    user.can_view_vehicles = True

def log_action(db: Session, action: str, details: str = "", by: str = "system"):
    db.add(ActivityLog(action=action, details=details, performed_by=by))
    db.commit()

def apply_role_permissions(user: User, role_ids: list):
    """Apply highest-priority matching Discord role permissions."""
    matched = None
    for rid in ROLE_PRIORITY:
        if rid in role_ids and rid in ROLE_MAP:
            matched = ROLE_MAP[rid]
            break
    # fallback: any matching role
    if not matched:
        for rid in role_ids:
            if rid in ROLE_MAP:
                matched = ROLE_MAP[rid]
                break
    if matched:
        user.rank = matched.get("rank", user.rank)
        user.clearance = matched.get("clearance", user.clearance)
        user.is_admin = matched.get("is_admin", False)
        user.can_view_map = matched.get("can_view_map", False)
        user.can_view_personnel = matched.get("can_view_personnel", False)
        user.can_manage_personnel = matched.get("can_manage_personnel", False)
        user.can_view_applications = matched.get("can_view_applications", False)
        user.can_manage_applications = matched.get("can_manage_applications", False)
        user.can_issue_id = matched.get("can_issue_id", False)
        user.can_view_logs = matched.get("can_view_logs", False)
        user.can_manage_blacklist = matched.get("can_manage_blacklist", False)
        user.can_view_vehicles = matched.get("can_view_vehicles", False)
    return matched is not None

async def broadcast(payload: dict):
    dead = set()
    for ws in connected_ws:
        try:
            await ws.send_json(payload)
        except Exception:
            dead.add(ws)
    for ws in dead:
        connected_ws.discard(ws)

async def poll_loop():
    while True:
        try:
            raw = await client.fetch_server(players=True, vehicles=True, join_logs=True)
            players = [ERLCClient.parse_player(p) for p in raw.get("Players", [])]
            vehicles = [ERLCClient.parse_vehicle(v) for v in raw.get("Vehicles", [])]
            join_logs = sorted(
                [ERLCClient.parse_join_log(j) for j in raw.get("JoinLogs", [])],
                key=lambda x: x.get("timestamp") or 0, reverse=True
            )[:80]
            latest_data.update({
                "players": players, "vehicles": vehicles, "join_logs": join_logs,
                "server": {
                    "name": raw.get("Name"),
                    "current_players": raw.get("CurrentPlayers"),
                    "max_players": raw.get("MaxPlayers"),
                },
                "last_update": raw.get("_fetched_at"),
                "player_count": len(players),
                "error": None,
            })
            await broadcast({"type": "update", "data": latest_data})
        except Exception as e:
            logger.error(f"Poll error: {e}")
            latest_data["error"] = str(e)
        await asyncio.sleep(settings.poll_interval)

@asynccontextmanager
async def lifespan(app: FastAPI):
    global poll_task
    init_db()
    db = SessionLocal()
    try:
        admin = db.query(User).filter(User.username == settings.admin_username).first()
        if not admin:
            admin = User(
                username=settings.admin_username,
                password_hash=hash_password(settings.admin_password),
                display_name="Director",
                rank="Director",
                clearance="Top Secret",
                is_admin=True,
                can_view_map=True, can_view_personnel=True, can_manage_personnel=True,
                can_view_applications=True, can_manage_applications=True,
                can_issue_id=True, can_view_logs=True, can_manage_blacklist=True,
                can_view_vehicles=True,
            )
            db.add(admin)
            db.commit()
            logger.info("Default admin created")
    finally:
        db.close()
    await client.start()
    poll_task = asyncio.create_task(poll_loop())
    logger.info("CIA Portal started")
    yield
    if poll_task:
        poll_task.cancel()
    await client.close()

app = FastAPI(title="CIA Intelligence Portal", lifespan=lifespan, docs_url=None, redoc_url=None)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Security headers middleware
@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://unpkg.com; "
        "style-src 'self' 'unsafe-inline' https://unpkg.com https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data: https://api.erlc.gg https://cdn.discordapp.com; "
        "connect-src 'self' wss: ws: https://api.erlc.gg; "
        "frame-ancestors 'none';"
    )
    if request.url.scheme == "https":
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response

app.add_middleware(
    SessionMiddleware,
    secret_key=settings.secret_key,
    max_age=settings.session_max_age,
    same_site="lax",
    https_only=not settings.debug,
)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ── Discord OAuth ────────────────────────────────────────
@app.get("/auth/discord")
@limiter.limit("6/minute")
async def discord_login(request: Request):
    if not settings.discord_client_id or not settings.discord_redirect_uri:
        return HTMLResponse("<h2>Discord OAuth not configured. Set DISCORD_CLIENT_ID and DISCORD_REDIRECT_URI.</h2>", status_code=500)
    state = secrets.token_urlsafe(24)
    request.session["oauth_state"] = state
    params = {
        "client_id": settings.discord_client_id,
        "redirect_uri": settings.discord_redirect_uri,
        "response_type": "code",
        "scope": "identify guilds guilds.members.read",
        "state": state,
        "prompt": "none",
    }
    return RedirectResponse(f"{DISCORD_AUTH}?{urlencode(params)}")

@app.get("/auth/discord/callback")
@limiter.limit("8/minute")
async def discord_callback(request: Request, code: str = None, state: str = None, error: str = None, db: Session = Depends(get_db)):
    ip = get_client_ip(request)
    blocked, ban_msg = is_ip_blocked(db, ip)
    if blocked:
        return templates.TemplateResponse("blocked.html", {"request": request, "message": ban_msg})
    if error:
        return RedirectResponse("/login?error=discord_denied")
    if not code or not state or state != request.session.get("oauth_state"):
        return RedirectResponse("/login?error=invalid_state")
    request.session.pop("oauth_state", None)

    # Exchange code for token
    async with httpx.AsyncClient() as http:
        token_resp = await http.post(
            DISCORD_TOKEN,
            data={
                "client_id": settings.discord_client_id,
                "client_secret": settings.discord_client_secret,
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": settings.discord_redirect_uri,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        if token_resp.status_code != 200:
            logger.error(f"Token error: {token_resp.text}")
            return RedirectResponse("/login?error=token_failed")
        token_data = token_resp.json()
        access_token = token_data.get("access_token")
        if not access_token:
            return RedirectResponse("/login?error=no_token")

        # User info
        user_resp = await http.get(
            f"{DISCORD_API}/users/@me",
            headers={"Authorization": f"Bearer {access_token}"},
        )
        if user_resp.status_code != 200:
            return RedirectResponse("/login?error=user_failed")
        duser = user_resp.json()
        discord_id = str(duser["id"])
        username = duser.get("username") or "Unknown"
        global_name = duser.get("global_name") or username
        avatar = duser.get("avatar") or ""

        # Member roles in guild
        role_ids = []
        if settings.discord_guild_id:
            # Prefer bot token if available
            headers = {}
            if settings.discord_bot_token:
                headers["Authorization"] = f"Bot {settings.discord_bot_token}"
                member_url = f"{DISCORD_API}/guilds/{settings.discord_guild_id}/members/{discord_id}"
            else:
                headers["Authorization"] = f"Bearer {access_token}"
                member_url = f"{DISCORD_API}/users/@me/guilds/{settings.discord_guild_id}/member"

            member_resp = await http.get(member_url, headers=headers)
            if member_resp.status_code == 200:
                member = member_resp.json()
                role_ids = [str(r) for r in member.get("roles", [])]
            else:
                logger.warning(f"Could not fetch member roles: {member_resp.status_code} {member_resp.text}")

    # Find or create user
    user = db.query(User).filter(User.discord_id == discord_id).first()
    if not user:
        # also try by username
        user = db.query(User).filter(User.username == username).first()
    if not user:
        user = User(
            username=username[:60],
            discord_id=discord_id,
            display_name=global_name[:100],
            discord_avatar=avatar,
            rank="Recruit",
            clearance="Restricted",
        )
        db.add(user)
    else:
        user.discord_id = discord_id
        user.display_name = global_name[:100]
        user.discord_avatar = avatar
        if not user.username:
            user.username = username[:60]

    # Apply role-based permissions
    has_role = apply_role_permissions(user, role_ids)
    if not has_role and not user.is_admin:
        # No mapped role and not admin → minimal access (can still login to see apply page)
        user.can_view_applications = True

    # Deny if locked
    locked, lock_msg = check_user_locked(user)
    if locked and not user.is_admin:
        record_security_event(db, "locked_attempt", get_client_ip(request), user.username, "Discord login blocked", "high")
        return templates.TemplateResponse("blocked.html", {"request": request, "message": lock_msg})

    elevate_if_owner(user)
    user.last_login = datetime.now(timezone.utc)
    if not user.is_locked:
        user.is_active = True
    db.commit()

    request.session["user_id"] = user.id
    request.session["login_method"] = "discord"
    log_action(db, "discord_login", f"{user.display_name} ({discord_id}) roles={role_ids}", user.username)
    return RedirectResponse("/", status_code=303)

# ── Auth Routes ──────────────────────────────────────────
@app.get("/login", response_class=HTMLResponse)
@limiter.limit("15/minute")
async def login_page(request: Request, db: Session = Depends(get_db)):
    ip = get_client_ip(request)
    blocked, ban_msg = is_ip_blocked(db, ip)
    if blocked:
        return templates.TemplateResponse("blocked.html", {"request": request, "message": ban_msg})
    error = request.query_params.get("error")
    err_msg = None
    if error == "discord_denied":
        err_msg = "تم رفض الدخول عبر Discord"
    elif error == "invalid_state":
        err_msg = "طلب غير صالح (state). حاول مرة أخرى."
    elif error == "token_failed":
        err_msg = "فشل الحصول على التوكن من Discord"
    elif error:
        err_msg = "حدث خطأ أثناء تسجيل الدخول"
    return templates.TemplateResponse("login.html", {
        "request": request,
        "error": err_msg,
        "discord_enabled": bool(settings.discord_client_id and settings.discord_redirect_uri),
    })

@app.post("/login")
@limiter.limit("5/minute")
async def login(request: Request, username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    ip = get_client_ip(request)
    # Block known bad IPs first
    blocked, ban_msg = is_ip_blocked(db, ip)
    if blocked:
        record_security_event(db, "blocked_attempt", ip, username, "Tried login while IP banned", "high")
        return templates.TemplateResponse("blocked.html", {"request": request, "message": ban_msg})

    user = db.query(User).filter(User.username == username).first()
    locked, lock_msg = check_user_locked(user)
    if locked:
        record_security_event(db, "locked_attempt", ip, username, "Tried locked account", "high")
        return templates.TemplateResponse("blocked.html", {"request": request, "message": lock_msg})

    if not user or not verify_password(password, user.password_hash or ""):
        result = handle_failed_login(db, ip, username)
        if result["ip_banned"] or result["account_locked"]:
            return templates.TemplateResponse("blocked.html", {"request": request, "message": result["message"]})
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": result["message"],
            "discord_enabled": bool(settings.discord_client_id),
        })

    # Success
    elevate_if_owner(user)
    reset_failed_on_success(db, user, ip)
    request.session["user_id"] = user.id
    request.session["login_method"] = "password"
    user.last_login = datetime.now(timezone.utc)
    db.commit()
    log_action(db, "login", f"User {user.username} from {ip}", user.username)
    return RedirectResponse("/", status_code=303)

@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)

# ── Main Pages ───────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    agents = db.query(User).filter(User.is_active == True).count()
    pending = db.query(Application).filter(Application.status == "pending").count()
    blacklist_count = db.query(Blacklist).count()
    recent_logs = db.query(ActivityLog).order_by(ActivityLog.created_at.desc()).limit(10).all()
    announcements = db.query(Announcement).order_by(Announcement.created_at.desc()).limit(5).all()
    on_duty = db.query(User).filter(User.duty_status == "on", User.is_active == True).count()
    return templates.TemplateResponse("dashboard.html", {
        "request": request, "user": user,
        "agents": agents, "pending": pending, "blacklist_count": blacklist_count,
        "recent_logs": recent_logs, "live": latest_data,
        "announcements": announcements, "on_duty": on_duty,
    })

@app.get("/map", response_class=HTMLResponse)
async def map_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_map and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    return templates.TemplateResponse("map.html", {
        "request": request, "user": user,
        "map_size": settings.map_size, "map_scale": settings.map_scale,
    })

@app.get("/personnel", response_class=HTMLResponse)
async def personnel(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_personnel and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    agents = db.query(User).order_by(User.rank, User.display_name).all()
    return templates.TemplateResponse("personnel.html", {"request": request, "user": user, "agents": agents})

@app.get("/applications", response_class=HTMLResponse)
async def applications_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_applications and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    apps = db.query(Application).order_by(Application.created_at.desc()).all()
    can_manage = user.can_manage_applications or user.is_admin
    return templates.TemplateResponse("applications.html", {
        "request": request, "user": user, "apps": apps, "can_manage": can_manage
    })

@app.get("/apply", response_class=HTMLResponse)
async def apply_page(request: Request):
    return templates.TemplateResponse("apply.html", {"request": request, "success": False})

@app.post("/apply")
@limiter.limit("3/minute")
async def submit_application(
    request: Request,
    app_type: str = Form("join"),
    full_name: str = Form(...),
    roblox_username: str = Form(...),
    roblox_id: str = Form(""),
    discord: str = Form(""),
    age: str = Form(""),
    experience: str = Form(""),
    reason: str = Form(""),
    db: Session = Depends(get_db)
):
    # basic sanitization length limits
    app = Application(
        app_type=app_type[:30],
        full_name=full_name[:100],
        roblox_username=roblox_username[:64],
        roblox_id=roblox_id[:30],
        discord=discord[:80],
        age=age[:10],
        experience=experience[:2000],
        reason=reason[:2000],
    )
    db.add(app)
    db.commit()
    log_action(db, "new_application", f"{app_type} from {full_name}")
    return templates.TemplateResponse("apply.html", {"request": request, "success": True})

@app.post("/applications/{app_id}/review")
async def review_app(app_id: int, request: Request, status: str = Form(...), note: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.can_manage_applications and not user.is_admin):
        return RedirectResponse("/applications", status_code=303)
    if status not in ("accepted", "rejected"):
        return RedirectResponse("/applications", status_code=303)
    app = db.query(Application).filter(Application.id == app_id).first()
    if app:
        app.status = status
        app.reviewer_note = note[:500]
        app.reviewed_by = user.username
        app.reviewed_at = datetime.now(timezone.utc)
        db.commit()
        log_action(db, "review_application", f"{status} app #{app_id}", user.username)
        # Notify Discord bot (separate process)
        event = "application_accepted" if status == "accepted" else "application_rejected"
        await notify_bot({
            "type": event,
            "discord": app.discord or "",
            "name": app.full_name,
            "reason": note[:300] if status == "rejected" else "",
        })
    return RedirectResponse("/applications", status_code=303)

@app.get("/id-card", response_class=HTMLResponse)
async def id_card_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    target = user
    target_id = request.query_params.get("uid")
    if target_id and (user.can_issue_id or user.is_admin):
        t = db.query(User).filter(User.id == int(target_id)).first()
        if t:
            target = t
    return templates.TemplateResponse("id_card.html", {"request": request, "user": user, "agent": target})

@app.get("/blacklist", response_class=HTMLResponse)
async def blacklist_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_manage_blacklist and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    items = db.query(Blacklist).order_by(Blacklist.created_at.desc()).all()
    return templates.TemplateResponse("blacklist.html", {"request": request, "user": user, "items": items})

@app.post("/blacklist/add")
async def add_blacklist(request: Request, username: str = Form(...), roblox_id: str = Form(""), reason: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.can_manage_blacklist and not user.is_admin):
        return RedirectResponse("/blacklist", status_code=303)
    db.add(Blacklist(username=username[:64], roblox_id=roblox_id[:30], reason=reason[:500], added_by=user.username))
    db.commit()
    log_action(db, "blacklist_add", username, user.username)
    return RedirectResponse("/blacklist", status_code=303)

@app.get("/logs", response_class=HTMLResponse)
async def logs_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.can_view_logs and not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    logs = db.query(ActivityLog).order_by(ActivityLog.created_at.desc()).limit(100).all()
    return templates.TemplateResponse("logs.html", {"request": request, "user": user, "logs": logs})

@app.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not user.is_admin:
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    users = db.query(User).order_by(User.id).all()
    return templates.TemplateResponse("admin.html", {"request": request, "user": user, "users": users})

@app.post("/admin/user")
async def create_or_update_user(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or not user.is_admin:
        return RedirectResponse("/admin", status_code=303)
    form = await request.form()
    uid = form.get("user_id")
    if uid:
        target = db.query(User).filter(User.id == int(uid)).first()
        if not target:
            return RedirectResponse("/admin", status_code=303)
        # Hierarchy protection: cannot demote/lock equal or higher (esp. ministers)
        if not can_manage_user(user.rank, user.is_admin, target.rank, target.is_admin, user.username, target.username):
            log_action(db, "admin_denied", f"Blocked edit on {target.username}", user.username)
            return RedirectResponse("/admin", status_code=303)
    else:
        uname = (form.get("username") or "").strip()
        if not uname:
            return RedirectResponse("/admin", status_code=303)
        target = User(username=uname[:64], password_hash=hash_password(form.get("password") or secrets.token_urlsafe(8)))
        db.add(target)

    target.display_name = (form.get("display_name") or target.username)[:100]
    target.rank = (form.get("rank") or "Recruit")[:50]
    target.clearance = (form.get("clearance") or "Confidential")[:20]
    target.callsign = (form.get("callsign") or "")[:30]
    target.roblox_id = (form.get("roblox_id") or "")[:30]
    target.is_active = form.get("is_active") == "on"
    target.is_admin = form.get("is_admin") == "on"
    target.can_view_map = form.get("can_view_map") == "on"
    target.can_view_personnel = form.get("can_view_personnel") == "on"
    target.can_manage_personnel = form.get("can_manage_personnel") == "on"
    target.can_view_applications = form.get("can_view_applications") == "on"
    target.can_manage_applications = form.get("can_manage_applications") == "on"
    target.can_issue_id = form.get("can_issue_id") == "on"
    target.can_view_logs = form.get("can_view_logs") == "on"
    target.can_manage_blacklist = form.get("can_manage_blacklist") == "on"
    target.can_view_vehicles = form.get("can_view_vehicles") == "on"
    if form.get("password"):
        target.password_hash = hash_password(form.get("password"))
    db.commit()
    log_action(db, "admin_user_update", f"User {target.username}", user.username)
    return RedirectResponse("/admin", status_code=303)




# ── Extra features ───────────────────────────────────────
@app.post("/duty/toggle")
async def duty_toggle(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    user.duty_status = "off" if user.duty_status == "on" else "on"
    db.commit()
    log_action(db, "duty_toggle", user.duty_status, user.username)
    return RedirectResponse("/", status_code=303)

@app.post("/announcements/add")
async def add_announcement(request: Request, title: str = Form(...), body: str = Form(""), priority: str = Form("normal"), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and not is_owner_identity(user.username)):
        return RedirectResponse("/", status_code=303)
    db.add(Announcement(title=title[:120], body=body[:2000], priority=priority[:20], author=user.username))
    db.commit()
    log_action(db, "announcement", title[:80], user.username)
    await notify_bot({
        "type": "announcement",
        "title": title[:120],
        "body": body[:1500],
        "priority": priority[:20],
    })
    return RedirectResponse("/", status_code=303)

@app.post("/profile/codename")
async def set_codename(request: Request, codename: str = Form(""), db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    user.codename = (codename or "")[:40]
    db.commit()
    return RedirectResponse("/id-card", status_code=303)

# ── Security Center (Director / Minister) ────────────────
@app.get("/security", response_class=HTMLResponse)
async def security_center(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    if not user.is_admin and rank_level(user.rank) < 90 and not is_owner_identity(user.username):
        return templates.TemplateResponse("denied.html", {"request": request, "user": user})
    events = db.query(SecurityEvent).order_by(SecurityEvent.created_at.desc()).limit(50).all()
    blocked = db.query(BlockedIP).order_by(BlockedIP.created_at.desc()).all()
    locked_users = db.query(User).filter((User.is_locked == True) | (User.is_active == False)).all()
    return templates.TemplateResponse("security.html", {
        "request": request, "user": user,
        "events": events, "blocked": blocked, "locked_users": locked_users,
    })

@app.post("/security/unlock-user/{uid}")
async def unlock_user(uid: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 90):
        return RedirectResponse("/security", status_code=303)
    target = db.query(User).filter(User.id == uid).first()
    if target and can_manage_user(user.rank, user.is_admin, target.rank, target.is_admin, user.username, target.username):
        target.is_locked = False
        target.is_active = True
        target.failed_attempts = 0
        target.locked_reason = ""
        db.commit()
        log_action(db, "unlock_user", target.username, user.username)
    return RedirectResponse("/security", status_code=303)

@app.post("/security/unblock-ip/{ip_id}")
async def unblock_ip(ip_id: int, request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user or (not user.is_admin and rank_level(user.rank) < 90):
        return RedirectResponse("/security", status_code=303)
    row = db.query(BlockedIP).filter(BlockedIP.id == ip_id).first()
    if row:
        db.delete(row)
        db.commit()
        log_action(db, "unblock_ip", row.ip_address, user.username)
    return RedirectResponse("/security", status_code=303)

# ── AI Assistant ─────────────────────────────────────────
@app.get("/ai", response_class=HTMLResponse)
async def ai_page(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse("ai.html", {"request": request, "user": user})

@app.post("/api/ai/chat")
@limiter.limit("20/minute")
async def ai_chat_api(request: Request, db: Session = Depends(get_db)):
    user = get_current_user(request, db)
    if not user:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "bad request"}, status_code=400)
    message = (body.get("message") or "").strip()
    history = body.get("history") or []
    if not message or len(message) > 2000:
        return JSONResponse({"error": "invalid message"}, status_code=400)
    reply = await ai_chat(history, message)
    return {"reply": reply}

# ── API / WS ─────────────────────────────────────────────
@app.get("/api/status")
@limiter.limit("30/minute")
async def api_status(request: Request):
    return {"ok": True, "player_count": latest_data["player_count"], "last_update": latest_data["last_update"]}

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    connected_ws.add(ws)
    await ws.send_json({"type": "update", "data": latest_data})
    try:
        while True:
            data = await ws.receive_text()
            if data == "ping":
                await ws.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        connected_ws.discard(ws)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=settings.port, reload=settings.debug)

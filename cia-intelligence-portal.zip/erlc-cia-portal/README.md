# CIA Intelligence Portal — ER:LC

موقع متكامل لقطاع CIA مع تسجيل دخول Discord + صلاحيات حسب الرول + حماية أمنية قوية.

## المميزات الأمنية
- Rate limiting على صفحات الدخول والتقديم
- Security Headers (CSP, HSTS, X-Frame-Options, ...)
- Sessions آمنة (SameSite + HTTPS only)
- إخفاء /docs و /redoc
- تحقق من OAuth state ضد CSRF
- عدم تخزين الـ Client Secret في الكود

## Discord Role Mapping
الرول `1525986271447613642` = Recruit (يشوف التقديمات فقط).
عدّل `ROLE_MAP` في `config.py` لإضافة رولات أخرى.

## إعداد Render

### Environment Variables (ضعها كلها):
```
ERLC_SERVER_KEY=...
SECRET_KEY=...long random...
DISCORD_CLIENT_ID=1562116918343630919
DISCORD_CLIENT_SECRET=UcOi25La7ZpiLVvi4oJKXUCt9uAGLeD3
DISCORD_GUILD_ID=1519570369239978104
DISCORD_REDIRECT_URI=https://YOUR-APP.onrender.com/auth/discord/callback
ADMIN_USERNAME=admin
ADMIN_PASSWORD=...
```

### Discord Developer Portal
1. OAuth2 → Redirects → أضف نفس رابط DISCORD_REDIRECT_URI
2. OAuth2 → Scopes: identify, guilds, guilds.members.read
3. (مستحسن) أنشئ بوت وفعّل Server Members Intent، ثم ضع DISCORD_BOT_TOKEN

### Build / Start
- Build: `pip install -r requirements.txt`
- Start: `uvicorn main:app --host 0.0.0.0 --port $PORT`

## ملاحظات
- بعد أول دخول بـ Discord يتم إنشاء الحساب تلقائياً وربط الرول.
- الأدمن الافتراضي يبقى متاحاً باليوزر/باسورد.

from pydantic_settings import BaseSettings
from typing import Dict, Any

class Settings(BaseSettings):
    erlc_server_key: str = "changeme"
    secret_key: str = "CHANGE-ME-TO-A-LONG-RANDOM-STRING-AT-LEAST-32-CHARS"
    session_max_age: int = 60 * 60 * 12

    # Discord OAuth – put real values in Render Environment Variables only
    discord_client_id: str = ""
    discord_client_secret: str = ""
    discord_guild_id: str = ""
    discord_redirect_uri: str = ""  # https://YOUR-APP.onrender.com/auth/discord/callback
    discord_bot_token: str = ""     # optional but recommended

    poll_interval: float = 4.0
    port: int = 8000
    debug: bool = False
    admin_username: str = "admin"
    admin_password: str = "ChangeMe123!"
    map_size: int = 5355
    map_scale: float = 1.0
    database_url: str = "sqlite:///./data/cia.db"

    # Optional AI (OpenAI-compatible: OpenAI, xAI Grok, etc.)
    ai_api_key: str = ""
    ai_base_url: str = "https://api.openai.com/v1"
    ai_model: str = "gpt-4o-mini"

    # Standalone Discord bot notify bridge (optional)
    bot_notify_url: str = ""   # e.g. http://your-vps:8090/notify
    bot_notify_secret: str = ""

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()

# Discord Role ID → rank + permissions
# Role 1525986271447613642 = New members → Recruit (view applications only)
ROLE_MAP: Dict[str, Dict[str, Any]] = {
    "1525986271447613642": {
        "rank": "Recruit",
        "clearance": "Restricted",
        "is_admin": False,
        "can_view_map": False,
        "can_view_personnel": False,
        "can_manage_personnel": False,
        "can_view_applications": True,
        "can_manage_applications": False,
        "can_issue_id": False,
        "can_view_logs": False,
        "can_manage_blacklist": False,
        "can_view_vehicles": False,
    },
}

# Highest priority first when multiple roles match
ROLE_PRIORITY = [
    "1525986271447613642",  # Recruit — applications only
    # Add higher Discord role IDs above Recruit in this list (first match wins if you reorder)
]

# Manual ranks used in admin UI: Minister, Director, Deputy Director, SAC, Special Agent, Agent, Recruit

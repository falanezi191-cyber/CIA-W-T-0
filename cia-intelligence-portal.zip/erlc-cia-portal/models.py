from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text
from database import Base

def utcnow():
    return datetime.now(timezone.utc)

class Announcement(Base):
    __tablename__ = "announcements"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(120), nullable=False)
    body = Column(Text, default="")
    priority = Column(String(20), default="normal")  # normal, high, critical
    author = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    password_hash = Column(String(128), nullable=True)
    discord_id = Column(String(32), unique=True, nullable=True, index=True)
    discord_avatar = Column(String(128), default="")
    display_name = Column(String(100), nullable=False)
    rank = Column(String(50), default="Recruit")
    clearance = Column(String(20), default="Confidential")
    callsign = Column(String(30), default="")
    roblox_id = Column(String(30), default="")
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    is_locked = Column(Boolean, default=False)  # permanent lock after attack
    locked_reason = Column(Text, default="")
    locked_at = Column(DateTime, nullable=True)
    failed_attempts = Column(Integer, default=0)
    can_view_map = Column(Boolean, default=False)
    can_view_personnel = Column(Boolean, default=False)
    can_manage_personnel = Column(Boolean, default=False)
    can_view_applications = Column(Boolean, default=False)
    can_manage_applications = Column(Boolean, default=False)
    can_issue_id = Column(Boolean, default=False)
    can_view_logs = Column(Boolean, default=False)
    can_manage_blacklist = Column(Boolean, default=False)
    can_view_vehicles = Column(Boolean, default=True)
    notes = Column(Text, default="")
    duty_status = Column(String(20), default="off")  # on / off / training
    codename = Column(String(40), default="")
    joined_at = Column(DateTime, default=utcnow)
    last_login = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=utcnow)

class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True, index=True)
    app_type = Column(String(30), default="join")
    full_name = Column(String(100), nullable=False)
    roblox_username = Column(String(64), nullable=False)
    roblox_id = Column(String(30), default="")
    discord = Column(String(80), default="")
    age = Column(String(10), default="")
    experience = Column(Text, default="")
    reason = Column(Text, default="")
    status = Column(String(20), default="pending")
    reviewer_note = Column(Text, default="")
    reviewed_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)
    reviewed_at = Column(DateTime, nullable=True)

class Blacklist(Base):
    __tablename__ = "blacklist"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), nullable=False)
    roblox_id = Column(String(30), default="")
    reason = Column(Text, default="")
    added_by = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class ActivityLog(Base):
    __tablename__ = "activity_logs"
    id = Column(Integer, primary_key=True, index=True)
    action = Column(String(100), nullable=False)
    details = Column(Text, default="")
    performed_by = Column(String(64), default="system")
    ip_address = Column(String(64), default="")
    created_at = Column(DateTime, default=utcnow)

class SecurityEvent(Base):
    """Track attacks, failed logins, blocked IPs"""
    __tablename__ = "security_events"
    id = Column(Integer, primary_key=True, index=True)
    event_type = Column(String(50), nullable=False)  # failed_login, blocked_ip, locked_account, rate_limit
    ip_address = Column(String(64), default="", index=True)
    username = Column(String(64), default="")
    details = Column(Text, default="")
    severity = Column(String(20), default="medium")  # low, medium, high, critical
    created_at = Column(DateTime, default=utcnow)

class BlockedIP(Base):
    """Permanently or temporarily blocked IPs"""
    __tablename__ = "blocked_ips"
    id = Column(Integer, primary_key=True, index=True)
    ip_address = Column(String(64), unique=True, nullable=False, index=True)
    reason = Column(Text, default="")
    permanent = Column(Boolean, default=False)
    blocked_until = Column(DateTime, nullable=True)
    failed_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=utcnow)
